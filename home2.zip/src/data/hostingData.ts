import { HostingPlan, VpsTier, DedicatedServer, Testimonial, LeadRecord } from '../types';

export interface ImagePricingPlan {
  id: string;
  name: string;
  badge?: string;
  isPopular?: boolean;
  discountBadge: string;
  headline: string;
  prices: {
    '48': { monthlyUSD: number; originalUSD: number; totalUSD: number; renewalUSD: number; monthlyINR: number; originalINR: number; totalINR: number; renewalINR: number };
    '24': { monthlyUSD: number; originalUSD: number; totalUSD: number; renewalUSD: number; monthlyINR: number; originalINR: number; totalINR: number; renewalINR: number };
    '12': { monthlyUSD: number; originalUSD: number; totalUSD: number; renewalUSD: number; monthlyINR: number; originalINR: number; totalINR: number; renewalINR: number };
    '1': { monthlyUSD: number; originalUSD: number; totalUSD: number; renewalUSD: number; monthlyINR: number; originalINR: number; totalINR: number; renewalINR: number };
  };
  promoBanner: {
    title: string;
    description: string;
    creditsBadge: string;
    tooltip?: string;
  };
  features: {
    text: string;
    included: boolean;
    highlight?: boolean;
    tooltip?: string;
  }[];
  buildWith: {
    name: string;
    icon: string;
    included: boolean;
    tooltip?: string;
  }[];
  communicateGrow: {
    text: string;
    included: boolean;
    highlight?: boolean;
    tooltip?: string;
  }[];
  whyThisPlan?: {
    title: string;
    text: string;
  };
}

export const ATTACHED_IMAGE_PLANS: ImagePricingPlan[] = [
  {
    id: 'premium',
    name: 'Premium',
    discountBadge: '81% OFF',
    headline: 'Ideal hosting plan for beginners and bloggers.',
    prices: {
      '48': {
        monthlyUSD: 1.19,
        originalUSD: 1.79,
        totalUSD: 57.12,
        renewalUSD: 1.79,
        monthlyINR: 99.99,
        originalINR: 149.99,
        totalINR: 4799.52,
        renewalINR: 149.99,
      },
      '24': {
        monthlyUSD: 1.39,
        originalUSD: 1.79,
        totalUSD: 33.36,
        renewalUSD: 1.79,
        monthlyINR: 119.99,
        originalINR: 149.99,
        totalINR: 2879.76,
        renewalINR: 149.99,
      },
      '12': {
        monthlyUSD: 1.59,
        originalUSD: 1.79,
        totalUSD: 19.08,
        renewalUSD: 1.79,
        monthlyINR: 129.99,
        originalINR: 149.99,
        totalINR: 1559.88,
        renewalINR: 149.99,
      },
      '1': {
        monthlyUSD: 1.79,
        originalUSD: 1.79,
        totalUSD: 1.79,
        renewalUSD: 1.79,
        monthlyINR: 149.99,
        originalINR: 149.99,
        totalINR: 149.99,
        renewalINR: 149.99,
      },
    },
    promoBanner: {
      title: 'Free Domain+',
      description: 'Canva Pro for 1yr on 24months Plan',
      creditsBadge: 'Free Domain + Canva Pro',
      tooltip: 'Get 1 Year Free Domain (.com/.in) plus 1 Year Canva Pro subscription on 24 & 48-month plans.',
    },
    features: [
      { text: '3 websites', included: true },
      { text: 'Free Domain for 1 year', included: true, highlight: true, tooltip: 'Claim 1 year free .com, .in, .net or .org domain with WHOIS privacy & DNS protection.' },
      { text: '20 GB SSD Storage', included: true, tooltip: 'High-speed SSD Storage with automated weekly backups and 99% uptime guarantee.' },
      { text: 'Free weekly backups', included: true },
      { text: 'Ecommerce available', included: true },
      { text: 'CDN', included: true },
      { text: 'Priority 24/7 expert support', included: false },
    ],
    buildWith: [
      { name: 'AI Builder', icon: 'Bot', included: true },
      { name: 'WordPress', icon: 'Globe', included: true },
      { name: 'AI assistant for your online store', icon: 'ShoppingBag', included: true },
      { name: 'Node.js', icon: 'Cpu', included: false },
    ],
    communicateGrow: [
      { text: 'Webmail – 2 mailboxes per website', included: true, tooltip: 'Secure Webmail with spam protection, IMAP/SMTP support & mobile Gmail/Outlook sync.' },
      { text: 'AI email marketing', included: false },
    ],
  },
  {
    id: 'business',
    name: 'Business',
    discountBadge: '77% OFF',
    headline: 'Level up with more power and enhanced features.',
    prices: {
      '48': {
        monthlyUSD: 2.39,
        originalUSD: 3.59,
        totalUSD: 114.72,
        renewalUSD: 3.59,
        monthlyINR: 199.99,
        originalINR: 299.99,
        totalINR: 9599.52,
        renewalINR: 299.99,
      },
      '24': {
        monthlyUSD: 2.69,
        originalUSD: 3.59,
        totalUSD: 64.56,
        renewalUSD: 3.59,
        monthlyINR: 229.99,
        originalINR: 299.99,
        totalINR: 5519.76,
        renewalINR: 299.99,
      },
      '12': {
        monthlyUSD: 2.99,
        originalUSD: 3.59,
        totalUSD: 35.88,
        renewalUSD: 3.59,
        monthlyINR: 259.99,
        originalINR: 299.99,
        totalINR: 3119.88,
        renewalINR: 299.99,
      },
      '1': {
        monthlyUSD: 3.59,
        originalUSD: 3.59,
        totalUSD: 3.59,
        renewalUSD: 3.59,
        monthlyINR: 299.99,
        originalINR: 299.99,
        totalINR: 299.99,
        renewalINR: 299.99,
      },
    },
    promoBanner: {
      title: 'Free Domain+',
      description: 'Canva Pro for 1yr on 24months Plan',
      creditsBadge: 'Free Domain + Canva Pro',
      tooltip: 'Get 1 Year Free Domain (.com/.in) plus 1 Year Canva Pro subscription on 24 & 48-month plans.',
    },
    features: [
      { text: '50 websites', included: true },
      { text: 'Free Domain for 1 year', included: true, highlight: true, tooltip: 'Claim 1 year free .com, .in, .net or .org domain with WHOIS privacy & DNS protection.' },
      { text: '50 GB NVMe Storage', included: true, tooltip: 'Ultra-fast Gen4 NVMe Storage delivering up to 7,500 MB/s read/write speed for instant page loads.' },
      { text: 'Daily backups + easy data restore', included: true },
      { text: 'Ecommerce available', included: true },
      { text: 'CDN included', included: true },
      { text: 'Priority 24/7 expert support', included: false },
    ],
    buildWith: [
      { name: 'AI Builder', icon: 'Bot', included: true },
      { name: 'WordPress', icon: 'Globe', included: true },
      { name: 'AI assistant for your online store', icon: 'ShoppingBag', included: true },
      { name: 'Node.js', icon: 'Cpu', included: true },
    ],
    communicateGrow: [
      { text: 'Webmail – 5 mailboxes per website', included: true, tooltip: 'Secure Webmail with spam protection, IMAP/SMTP support & mobile Gmail/Outlook sync.' },
      { text: 'Free AI email marketing for 6 months', included: true },
    ],
  },
  {
    id: 'cloud-startup',
    name: 'Cloud Startup',
    badge: 'Special offer • 72% off',
    isPopular: true,
    discountBadge: '72% OFF',
    headline: 'Enjoy optimized performance & powerful resources.',
    prices: {
      '48': {
        monthlyUSD: 4.79,
        originalUSD: 5.99,
        totalUSD: 229.92,
        renewalUSD: 5.99,
        monthlyINR: 399.99,
        originalINR: 499.99,
        totalINR: 19199.52,
        renewalINR: 499.99,
      },
      '24': {
        monthlyUSD: 5.19,
        originalUSD: 5.99,
        totalUSD: 124.56,
        renewalUSD: 5.99,
        monthlyINR: 439.99,
        originalINR: 499.99,
        totalINR: 10559.76,
        renewalINR: 499.99,
      },
      '12': {
        monthlyUSD: 5.59,
        originalUSD: 5.99,
        totalUSD: 67.08,
        renewalUSD: 5.99,
        monthlyINR: 469.99,
        originalINR: 499.99,
        totalINR: 5639.88,
        renewalINR: 499.99,
      },
      '1': {
        monthlyUSD: 5.99,
        originalUSD: 5.99,
        totalUSD: 5.99,
        renewalUSD: 5.99,
        monthlyINR: 499.99,
        originalINR: 499.99,
        totalINR: 499.99,
        renewalINR: 499.99,
      },
    },
    promoBanner: {
      title: 'Free Domain+',
      description: 'Canva Pro for 1yr on 24months Plan',
      creditsBadge: 'Free Domain + Canva Pro',
      tooltip: 'Get 1 Year Free Domain (.com/.in) plus 1 Year Canva Pro subscription on 24 & 48-month plans.',
    },
    features: [
      { text: '100 websites', included: true, highlight: true },
      { text: 'Free Domain for 1 year', included: true, highlight: true, tooltip: 'Claim 1 year free .com, .in, .net or .org domain with WHOIS privacy & DNS protection.' },
      { text: '100 GB NVMe Storage', included: true, tooltip: 'Ultra-fast Gen4 NVMe Storage delivering up to 7,500 MB/s read/write speed for instant page loads.' },
      { text: 'Daily backups + easy data restore', included: true },
      { text: 'CDN included', included: true },
      { text: 'Ecommerce available', included: true },
      { text: 'Priority 24/7 expert support', included: true, highlight: true },
    ],
    buildWith: [
      { name: 'AI Builder', icon: 'Bot', included: true },
      { name: 'WordPress', icon: 'Globe', included: true },
      { name: 'AI assistant for your online store', icon: 'ShoppingBag', included: true },
      { name: 'Node.js', icon: 'Cpu', included: true },
    ],
    communicateGrow: [
      { text: 'Webmail – Unlimited mailboxes', included: true, highlight: true, tooltip: 'Unlimited Webmail accounts with spam filtering, custom domains, and mobile email clients.' },
      { text: 'Free AI email marketing for 1 year up to 250 subscribers', included: true },
    ],
    whyThisPlan: {
      title: 'Why this plan?',
      text: 'Optimized performance, NVMe storage, and isolated resources for scaling businesses.',
    },
  },
  {
    id: 'cloud-pro',
    name: 'Cloud Pro',
    discountBadge: '65% OFF',
    headline: 'Hosting for high-traffic sites and large-scale projects.',
    prices: {
      '48': {
        monthlyUSD: 5.99,
        originalUSD: 8.39,
        totalUSD: 287.52,
        renewalUSD: 8.39,
        monthlyINR: 499.99,
        originalINR: 699.99,
        totalINR: 23999.52,
        renewalINR: 699.99,
      },
      '24': {
        monthlyUSD: 6.79,
        originalUSD: 8.39,
        totalUSD: 162.96,
        renewalUSD: 8.39,
        monthlyINR: 569.99,
        originalINR: 699.99,
        totalINR: 13679.76,
        renewalINR: 699.99,
      },
      '12': {
        monthlyUSD: 7.49,
        originalUSD: 8.39,
        totalUSD: 89.88,
        renewalUSD: 8.39,
        monthlyINR: 629.99,
        originalINR: 699.99,
        totalINR: 7559.88,
        renewalINR: 699.99,
      },
      '1': {
        monthlyUSD: 8.39,
        originalUSD: 8.39,
        totalUSD: 8.39,
        renewalUSD: 8.39,
        monthlyINR: 699.99,
        originalINR: 699.99,
        totalINR: 699.99,
        renewalINR: 699.99,
      },
    },
    promoBanner: {
      title: 'Free Domain+',
      description: 'Canva Pro for 1yr on 24months Plan',
      creditsBadge: 'Free Domain + Canva Pro',
      tooltip: 'Get 1 Year Free Domain (.com/.in) plus 1 Year Canva Pro subscription on 24 & 48-month plans.',
    },
    features: [
      { text: '300 websites', included: true, highlight: true },
      { text: 'Free Domain for 1 year', included: true, highlight: true, tooltip: 'Claim 1 year free .com, .in, .net or .org domain with WHOIS privacy & DNS protection.' },
      { text: '200 GB NVMe Storage', included: true, tooltip: 'Ultra-fast Gen4 NVMe Storage delivering up to 7,500 MB/s read/write speed for instant page loads.' },
      { text: 'Daily and on-demand backups', included: true },
      { text: 'Dedicated IP address', included: true },
      { text: 'CDN included', included: true },
      { text: 'Priority 24/7 expert support', included: true, highlight: true },
    ],
    buildWith: [
      { name: 'AI Builder', icon: 'Bot', included: true },
      { name: 'WordPress', icon: 'Globe', included: true },
      { name: 'AI assistant for your online store', icon: 'ShoppingBag', included: true },
      { name: 'Node.js', icon: 'Cpu', included: true },
    ],
    communicateGrow: [
      { text: 'Webmail – Unlimited mailboxes', included: true, tooltip: 'Unlimited Webmail accounts with spam filtering, custom domains, and mobile email clients.' },
      { text: 'Free AI email marketing for 1 year up to 500 subscribers', included: true },
    ],
    whyThisPlan: {
      title: 'Why this plan?',
      text: 'Dedicated IP address & dedicated compute allocations for high-concurrency traffic.',
    },
  },
];

export const HOSTING_PLANS: HostingPlan[] = [
  {
    id: 'premium',
    name: 'Premium',
    discount: '81% OFF',
    badgeType: 'discount',
    monthlyPrice: 99.99,
    originalPrice: 149.99,
    description: 'Ideal hosting plan for beginners and bloggers.',
    renewalPriceText: 'Renews at ₹149.99/mo',
    perks: [
      { text: '3 Websites', badge: 'INCLUDED' },
      { text: 'Domain - free for 1 year', badge: 'FREE' },
      { text: '20 GB SSD storage', badge: 'FAST' },
      { text: 'Free weekly backups', badge: 'AUTOMATED' },
      { text: 'Ecommerce available', badge: 'STORE' },
    ],
    specs: {
      websites: '3 websites',
      storage: '20 GB SSD storage',
      emails: '2 Business Emails',
      aiBuilder: true,
      ftp: 'Unlimited FTP',
      bandwidth: 'Unmetered Bandwidth',
      vcpu: '1 vCPU Core',
      ram: '1.5 GB RAM',
      ioLimit: '5 MB/s IO limit',
      sqlDatabases: 'Unlimited SQL',
      addonDatabases: true,
    },
  },
  {
    id: 'business',
    name: 'Business',
    discount: '77% OFF',
    badgeType: 'discount',
    monthlyPrice: 199.99,
    originalPrice: 299.99,
    description: 'Level up with more power and enhanced features.',
    renewalPriceText: 'Renews at ₹299.99/mo',
    perks: [
      { text: '50 Websites', badge: 'INCLUDED' },
      { text: 'Domain - free for 1 year', badge: 'FREE' },
      { text: '50 GB NVMe storage', badge: 'GEN4' },
      { text: 'Daily backups + easy restore', badge: 'DAILY' },
      { text: 'Node.js & AI Builder', badge: 'DEV' },
    ],
    specs: {
      websites: '50 websites',
      storage: '50 GB NVMe SSD',
      emails: '5 Business Emails',
      aiBuilder: true,
      ftp: 'Unlimited FTP',
      bandwidth: 'Unmetered Bandwidth',
      vcpu: '2 vCPU Cores',
      ram: '2 GB RAM',
      ioLimit: '10 MB/s IO limit',
      sqlDatabases: 'Unlimited SQL',
      addonDatabases: true,
    },
  },
  {
    id: 'cloud-startup',
    name: 'Cloud Startup',
    badge: 'Special offer • 72% off',
    discount: '72% OFF',
    badgeType: 'popular',
    monthlyPrice: 399.99,
    originalPrice: 499.99,
    description: 'Enjoy optimized performance & powerful resources.',
    renewalPriceText: 'Renews at ₹499.99/mo',
    perks: [
      { text: '100 Websites', badge: 'UNLIMITED' },
      { text: 'Domain - free for 1 year', badge: 'FREE' },
      { text: '100 GB NVMe storage', badge: 'GEN4' },
      { text: 'Daily backups + easy data restore', badge: 'DAILY' },
      { text: 'Priority 24/7 expert support', badge: 'VIP' },
    ],
    specs: {
      websites: '100 websites',
      storage: '100 GB NVMe SSD',
      emails: 'Unlimited Business Email',
      aiBuilder: true,
      ftp: 'Unlimited FTP',
      bandwidth: 'Unmetered Bandwidth',
      vcpu: '3 vCPU Cores',
      ram: '3 GB RAM',
      ioLimit: '15 MB/s IO limit',
      sqlDatabases: 'Unlimited SQL',
      addonDatabases: true,
    },
  },
  {
    id: 'cloud-pro',
    name: 'Cloud Pro',
    discount: '65% OFF',
    badgeType: 'discount',
    monthlyPrice: 499.99,
    originalPrice: 699.99,
    description: 'Hosting for high-traffic sites and large-scale projects.',
    renewalPriceText: 'Renews at ₹699.99/mo',
    perks: [
      { text: '300 Websites', badge: 'ENTERPRISE' },
      { text: 'Domain - free for 1 year', badge: 'FREE' },
      { text: '200 GB NVMe storage', badge: 'GEN4' },
      { text: 'Daily & on-demand snapshots', badge: 'SNAP' },
      { text: 'Dedicated IP address', badge: 'STATIC IP' },
    ],
    specs: {
      websites: '300 websites',
      storage: '200 GB NVMe SSD',
      emails: 'Unlimited Business Email',
      aiBuilder: true,
      ftp: 'Unlimited FTP',
      bandwidth: 'Unmetered Bandwidth',
      vcpu: '4 vCPU Cores',
      ram: '4 GB RAM',
      ioLimit: '25 MB/s IO limit',
      sqlDatabases: 'Unlimited SQL',
      addonDatabases: true,
    },
  },
];

export const VPS_TIERS: VpsTier[] = [
  {
    id: 'vps-1',
    tierNumber: 1,
    name: 'Cloud VPS 1',
    popularTag: 'POPULAR FOR DEVELOPERS',
    monthlyPrice: 999,
    originalPrice: 1999,
    discountBadge: '50% OFF',
    vcpu: 2,
    ramGb: 4,
    nvmeGb: 40,
    bandwidthMbps: 500,
    features: [
      '2 vCore Dedicated Compute',
      '4 GB RAM Memory',
      '40 GB NVMe Enterprise',
      'Unlimited traffic 500 Mbps',
      'Daily backup included',
      'Full Root SSH & IPMI Access',
    ],
  },
  {
    id: 'vps-2',
    tierNumber: 2,
    name: 'Cloud VPS 2',
    popularTag: 'BEST VALUE SCALING',
    monthlyPrice: 1799,
    originalPrice: 3599,
    discountBadge: '50% OFF',
    vcpu: 4,
    ramGb: 8,
    nvmeGb: 80,
    bandwidthMbps: 1000,
    features: [
      '4 vCore Dedicated Compute',
      '8 GB RAM Memory',
      '80 GB NVMe Enterprise',
      'Unlimited traffic 1 Gbps',
      'Automated snapshot restore',
      'DDoS Protection 100 Gbps',
    ],
  },
  {
    id: 'vps-3',
    tierNumber: 3,
    name: 'Cloud VPS 3',
    popularTag: 'HIGH PERFORMANCE',
    monthlyPrice: 2999,
    originalPrice: 5999,
    discountBadge: '50% OFF',
    vcpu: 8,
    ramGb: 16,
    nvmeGb: 160,
    bandwidthMbps: 1000,
    features: [
      '8 vCore Dedicated Compute',
      '16 GB RAM Memory',
      '160 GB NVMe Enterprise',
      'Dedicated IP included',
      'Custom ISO & Kernel Install',
      'Sub-5ms India Latency',
    ],
  },
  {
    id: 'vps-4',
    tierNumber: 4,
    name: 'Cloud VPS 4',
    popularTag: 'ENTERPRISE APPS',
    monthlyPrice: 4999,
    originalPrice: 9999,
    discountBadge: '50% OFF',
    vcpu: 16,
    ramGb: 32,
    nvmeGb: 320,
    bandwidthMbps: 2000,
    features: [
      '16 vCore High-Frequency',
      '32 GB ECC RAM Memory',
      '320 GB NVMe Raid-10',
      'Dedicated SLA Guarantee',
      'BGP Routing & Anycast IP',
      'Priority 24/7 Phone Support',
    ],
  },
];

export const DEDICATED_SERVERS: DedicatedServer[] = [
  {
    id: 'ds-e3',
    model: 'Gity-Dedicated Alpha',
    category: 'Budget Dedicated',
    node: 'IN-MUM-01',
    coresThreads: '4 Cores / 8 Threads',
    cpuModel: 'Intel Xeon E3-1270v6 (3.8 GHz Turbo)',
    ram: '32 GB DDR4 ECC',
    storage: '2x 480 GB Enterprise NVMe (RAID-1)',
    network: '1 Gbps Unmetered Uplink (15 TB Included)',
    monthlyPrice: 5499,
    deployTime: 'Instant (15 mins)',
    features: ['IPMI 2.0 Web Console', 'Tier-4 Mumbai Datacenter', 'Hardware Firewall Included', 'Free cPanel Migration'],
  },
  {
    id: 'ds-silver',
    model: 'Gity-Dedicated Silver',
    category: 'Mid Enterprise',
    node: 'IN-BLR-02',
    coresThreads: '12 Cores / 24 Threads',
    cpuModel: 'Intel Xeon Silver 4310 (3.3 GHz Turbo)',
    ram: '64 GB DDR4 ECC',
    storage: '2x 960 GB Gen4 NVMe (7,000 MB/s)',
    network: '10 Gbps Burst Uplink (30 TB Included)',
    monthlyPrice: 9999,
    deployTime: '2 Hours Auto-Provision',
    features: ['Dual 10Gbps Uplinks', 'Enterprise SLA 99.99%', 'BGP Anycast IP Option', 'Imunify360 Unlimited'],
  },
  {
    id: 'ds-gold',
    model: 'Gity-Dedicated Gold Dual',
    category: 'High Compute & Fintech',
    node: 'IN-DEL-01',
    coresThreads: '32 Cores / 64 Threads',
    cpuModel: '2x AMD EPYC 7502 (3.35 GHz Max)',
    ram: '128 GB DDR4 ECC',
    storage: '4x 1.92 TB NVMe Hardware RAID-10',
    network: '10 Gbps Redundant Uplink',
    monthlyPrice: 18499,
    deployTime: 'Same Day Deployment',
    features: ['Hardware KVM over IP', 'Dedicated Account Manager', 'Custom Reverse DNS', 'DDoS Protection up to 500 Gbps'],
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'testi-shweta',
    name: 'Shweta Tiwari',
    role: 'Brand Manager',
    company: 'Glamour Vogue Jewels',
    avatar: '/src/assets/images/support_team_woman_1793935098144.jpg',
    quoteTitle: 'Ultra-Luxury Look with LiteSpeed Cache',
    quote:
      'Our bespoke jewelry showcase required ultra luxury-grade speed. High-res zoom on 4K diamond ornaments loads instantaneously on smartphones across 4G and 5G networks.',
    rating: 5,
    source: 'Trustpilot',
    verifiedTime: '2 weeks ago',
    categoryTag: 'Custom Website Designing',
    location: 'Jaipur',
    projectScope: 'Luxury E-Commerce Suite',
  },
  {
    id: 'testi-farhan',
    name: 'Farhan Akhtar Qureshi',
    role: 'Principal Consultant',
    company: 'CloudMatrix IT',
    avatar: '/src/assets/images/customer_avatar_farhan_1793935099574.jpg',
    quoteTitle: 'The Best White-Label Reseller Hosting in India',
    quote:
      'Managing 60+ WHM client accounts on the Turbo Reseller package. Whitelabel nameservers, custom billing integrations, and automated cPanel backups give me complete peace of mind.',
    rating: 5,
    source: 'Google',
    verifiedTime: '1 week ago',
    categoryTag: 'Reseller Web Hosting',
    location: 'Hyderabad',
    projectScope: 'Managed Client Fleet',
  },
  {
    id: 'testi-kavita',
    name: 'Kavita Menon',
    role: 'Managing Director',
    company: 'GreenSprout Foods',
    avatar: '/src/assets/images/customer_avatar_kavita_1793935099144.jpg',
    quoteTitle: '100% Inbox Delivery with Proper DKIM & DMARC',
    quote:
      'Zero email delivery rejections. Before Gitysoft, our invoices kept landing in client spam folders. With Gitysoft automated SPF, DKIM, and DMARC record generation, 100% land in inbox.',
    rating: 5,
    source: 'Google',
    verifiedTime: '4 days ago',
    categoryTag: 'Business Email Hosting',
    location: 'Thiruvananthapuram',
    projectScope: 'Corporate Email Architecture',
  },
  {
    id: 'testi-rajesh',
    name: 'Rajesh Singhania',
    role: 'Chief Technology Officer',
    company: 'OmniRetail Solutions',
    avatar: '/src/assets/images/datacenter_server_room_1793935095545.jpg',
    quoteTitle: 'Bare Metal Dedicated Servers Provisioned in 4 Hours',
    quote:
      'Isolated VLAN and physical hardware for our algorithmic trading desk with zero latency. Their provisioning team had the bare metal cluster online and verified within 4 hours.',
    rating: 5,
    source: 'Clutch',
    verifiedTime: '2 weeks ago',
    categoryTag: 'Dedicated Bare Metal & Cloud Hosting',
    location: 'Mumbai',
    projectScope: 'Custom ERP & Cloud Migration',
  },
  {
    id: 'testi-deshmukh',
    name: 'Dr. Manoj Deshmukh',
    role: 'Doctor & Clinic Director',
    company: 'Pulse Healthcare Clinics',
    avatar: '/src/assets/images/customer_avatar_farhan_1793935099574.jpg',
    quoteTitle: 'Patient Health Portal with Daily Offsite Backups',
    quote:
      'HIPAA-compliant patient records and telehealth video streaming run seamlessly with zero latency. Automatic daily offsite backups protect our patient history reliably. 5 stars all the way!',
    rating: 5,
    source: 'GoodFirms',
    verifiedTime: '6 days ago',
    categoryTag: 'HIPAA Compliant Cloud Hosting',
    location: 'Nagpur',
    projectScope: 'Health SaaS Infrastructure',
  },
];

export const SAMPLE_LEADS: LeadRecord[] = [
  {
    id: 'lead-1',
    businessName: 'The Taj Mahal Palace',
    category: 'Hotels & Hospitality',
    phone: '+91 22 6665-XXXX',
    rating: 4.9,
    reviewsCount: '12.4k',
    region: 'Mumbai',
    status: 'Verified',
  },
  {
    id: 'lead-2',
    businessName: 'Grand Hyatt Hotel',
    category: 'Hotels & Hospitality',
    phone: '+91 22 6676-XXXX',
    rating: 4.8,
    reviewsCount: '8.9k',
    region: 'Mumbai',
    status: 'Verified',
  },
  {
    id: 'lead-3',
    businessName: 'The Westin Koregaon',
    category: 'Hotels & Hospitality',
    phone: '+91 20 6721-XXXX',
    rating: 4.9,
    reviewsCount: '6.7k',
    region: 'Pune',
    status: 'Verified',
  },
  {
    id: 'lead-4',
    businessName: 'JW Marriott Sahar',
    category: 'Hotels & Hospitality',
    phone: '+91 22 6882-XXXX',
    rating: 4.8,
    reviewsCount: '10.2k',
    region: 'Mumbai',
    status: 'Verified',
  },
  {
    id: 'lead-5',
    businessName: 'Infinitum SaaS Systems',
    category: 'IT & Software',
    phone: '+91 80 4412-XXXX',
    rating: 4.9,
    reviewsCount: '4.3k',
    region: 'Bangalore',
    status: 'Verified',
  },
  {
    id: 'lead-6',
    businessName: 'PayZing Fintech Hub',
    category: 'Fintech & Banking',
    phone: '+91 12 4492-XXXX',
    rating: 4.7,
    reviewsCount: '3.1k',
    region: 'Delhi-NCR',
    status: 'Verified',
  },
];

export interface FaqCategory {
  id: string;
  name: string;
  icon: string;
  count: number;
  faqs: {
    question: string;
    answer: string;
    badge?: string;
  }[];
}

export const CATEGORIZED_FAQS: FaqCategory[] = [
  {
    id: 'popular',
    name: 'Popular Questions',
    icon: 'Sparkles',
    count: 5,
    faqs: [
      {
        question: 'Why should I choose the 48-month plan shown in the pricing table?',
        answer:
          'The 48-month plan offers our maximum discount of 81% to 85% off, locking in our lowest rates. You receive 2x Black Friday AI credits (up to 2,000 credits), free domain for 1 year, free SSL lifetime, and round-the-clock 24x7hrs Technical Assistance.',
        badge: 'Best Value',
      },
      {
        question: 'What kind of support do you offer (is it really 24/7)?',
        answer:
          'We provide true 24x7hrs Technical Assistance handled by veteran system engineers—never canned bots. You can reach our team via live chat, support tickets, email, or direct emergency phone hotline with an average response time of under 3 minutes.',
        badge: '24/7 Support',
      },
      {
        question: 'Do you provide 24x7hrs Technical Assistance?',
        answer:
          'Yes! All Web Hosting, Business Hosting, and Cloud VPS plans come with dedicated 24x7hrs Technical Assistance. Our certified system engineers and DevOps architects are available day and night to assist with migrations, DNS, SSL, and server optimization.',
      },
      {
        question: 'How fast will my website load on Gitysoft NVMe servers?',
        answer:
          'Our servers are powered by enterprise Gen4 NVMe storage (up to 7,000 MB/s read speeds), LiteSpeed Web Server Enterprise, HTTP/3 (QUIC) protocol, and built-in LSCache for WordPress. Average server response time (TTFB) is between 180ms to 350ms worldwide.',
      },
      {
        question: 'How do you compare to competitors like GoDaddy, Hostinger, and Bluehost?',
        answer:
          'Unlike legacy hosts that crowd hundreds of accounts on slow HDDs with steep renewal price jumps, Gitysoft gives you transparent pricing, free weekly/daily backups with 1-click restore, free domain for 1 year, and free white-glove site migration with 0 downtime.',
      },
    ],
  },
  {
    id: 'hosting',
    name: 'Hosting & 48-Mo Plans',
    icon: 'Server',
    count: 4,
    faqs: [
      {
        question: 'Can I switch between 48 months, 24 months, 12 months, or 1 month?',
        answer:
          'Yes! You can choose your desired commitment term using the dropdown at the top of the pricing section. While the 48-month term gives the biggest savings (85% off), all terms include the core hosting features, automated backups, and 24/7 support.',
        badge: 'Flexible Terms',
      },
      {
        question: 'What does "Unlimited Websites" mean in the Unlimited plan?',
        answer:
          'You can host as many domains and subdomains as you wish within your 50 GB NVMe storage quota, subject to our fair usage policy. Each website gets its own isolated cPanel environment, SSL certificate, and database allocations.',
      },
      {
        question: 'What are the Black Friday 2x AI Credits and how do I use them?',
        answer:
          'Each plan comes with double AI credits (e.g. 1,000 credits instead of 500 on the Unlimited plan). These credits can be used in our AI Website Builder to auto-generate full websites, copy, product descriptions, SEO tags, and AI e-commerce assistant dialogues.',
        badge: 'Bonus Feature',
      },
      {
        question: 'Can I upgrade my hosting plan later as my business grows?',
        answer:
          'Absolutely! You can upgrade your storage, RAM, vCPU cores, or switch from Shared Hosting to Cloud VPS or Dedicated Bare Metal at any time with zero downtime and prorated credit.',
      },
    ],
  },
  {
    id: 'domains',
    name: 'Domains & SSL',
    icon: 'Globe',
    count: 4,
    faqs: [
      {
        question: 'How do I claim my Free Domain for 1 year?',
        answer:
          'When purchasing any annual, 24-month, or 48-month plan, simply enter your desired domain name (.com, .in, .net, .org, or .co) during checkout or search via our Domain Search modal. The domain registration fee will be automatically discounted to ₹0 / $0.',
        badge: 'Free Domain',
      },
      {
        question: 'Are SSL certificates really free for lifetime?',
        answer:
          'Yes. We issue automated Let\'s Encrypt and Sectigo Wildcard SSL certificates for all your primary domains, subdomains, and addon domains. They renew automatically every 90 days with zero manual action required.',
      },
      {
        question: 'Can I transfer an existing domain registered elsewhere to Gitysoft?',
        answer:
          'Yes. You can initiate a domain transfer through your client area using your EPP/Auth code, or simply point your domain\'s nameservers to ns1.gitysoft.com and ns2.gitysoft.com to keep your current registrar.',
      },
      {
        question: 'Does Gitysoft include WHOIS Privacy Protection?',
        answer:
          'Yes! We include free WHOIS privacy masking on all eligible domain extensions (.com, .net, .org, etc.) so your personal address and phone number remain shielded from spammers and scraping bots.',
      },
    ],
  },
  {
    id: 'ai-tools',
    name: 'AI Builder & Tools',
    icon: 'Bot',
    count: 4,
    faqs: [
      {
        question: 'What is the AI Website Builder and how does it work?',
        answer:
          'Our AI Website Builder lets you describe your business or website idea in plain English (or Hindi). In under 60 seconds, it designs a responsive, beautiful multi-page website complete with tailored copy, royalty-free images, contact forms, and mobile optimizations.',
        badge: 'AI Powered',
      },
      {
        question: 'Can I edit the AI-generated website with drag-and-drop?',
        answer:
          'Yes! You get a visual drag-and-drop canvas editor where you can customize layouts, change fonts, tweak color palettes (like our signature #9810fa violet), add e-commerce products, and preview live on mobile/desktop before publishing.',
      },
      {
        question: 'Is WordPress supported alongside the AI Builder?',
        answer:
          'Yes, 100%. You can install WordPress with 1-click via Softaculous, or use the Gitysoft AI Builder. We pre-install LiteSpeed Cache plugin and configure Object Cache for maximum performance on WordPress.',
      },
      {
        question: 'How does the AI Assistant for online store work?',
        answer:
          'The store assistant handles automated customer inquiries, suggests cross-sells, writes high-converting product descriptions, and syncs order tracking status automatically over live chat.',
      },
    ],
  },
  {
    id: 'security',
    name: 'Security & Uptime',
    icon: 'Shield',
    count: 4,
    faqs: [
      {
        question: 'What security protections are included against hackers and DDoS?',
        answer:
          'All accounts include Imunify360 real-time malware scanning, automated brute-force defense, Web Application Firewall (WAF), proactive patch management, and up to 100 Gbps DDoS mitigation at the edge.',
        badge: 'Enterprise Security',
      },
      {
        question: 'How often are automated backups created and how do I restore?',
        answer:
          'Depending on your plan, backups are taken either weekly or daily and stored off-site in geographically redundant cloud storage. You can restore individual files, MySQL databases, or the entire website with 1 click in your cPanel dashboard.',
      },
      {
        question: 'Where are Gitysoft data centers located?',
        answer:
          'Our primary Tier-4 datacenters are strategically located in Mumbai (Maharashtra), Bangalore (Karnataka), and Delhi-NCR (India), with global edge CDN PoPs in Singapore, Frankfurt, London, and New York for ultra-fast worldwide routing.',
      },
      {
        question: 'What is the 99.99% Uptime SLA Guarantee?',
        answer:
          'We guarantee 99.99% electrical and network availability backed by dual redundant power feeds, N+2 diesel generators, enterprise BGP multi-homed bandwidth, and active health monitoring. If uptime falls below SLA, you receive service credits.',
      },
    ],
  },
  {
    id: 'migration',
    name: 'Migration & Support',
    icon: 'RefreshCw',
    count: 4,
    faqs: [
      {
        question: 'How does free white-glove migration work?',
        answer:
          'After ordering, submit a quick migration ticket with your old host details (cPanel backup or FTP/database credentials). Our dedicated migration specialists transfer your files, databases, and emails with zero downtime and verify everything before pointing DNS.',
        badge: 'Free Migration',
      },
      {
        question: 'Will my current website experience any downtime during migration?',
        answer:
          'No! We replicate your entire website and test it using a temporary preview URL before changing DNS. Your visitors will experience zero downtime or interruption.',
      },
      {
        question: 'How can I contact your support team?',
        answer:
          'You can click the 24/7 Live Support button on the bottom right of the screen, submit a ticket via our portal, or email support@gitysoft.com. Live chat connects you with a certified Linux/cloud engineer within 3 minutes.',
      },
      {
        question: 'Do you provide email mailboxes with spam filtering?',
        answer:
          'Yes! Every plan includes business mailboxes (e.g., hello@yourdomain.com) with SpamAssassin AI filtering, webmail access, DKIM/SPF/DMARC authentication, and IMAP/SMTP support for Outlook, iPhone, and Android.',
      },
    ],
  },
];

export const FAQS = CATEGORIZED_FAQS[0].faqs;
