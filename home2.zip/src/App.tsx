import React, { useState } from 'react';
import { Currency, BillingCycle } from './types';
import { HeroSection } from './components/HeroSection';
import { PillarCards } from './components/PillarCards';
import { HostingPlans } from './components/HostingPlans';
import { ArchitectureTabs } from './components/ArchitectureTabs';
import { PriceComparison } from './components/PriceComparison';
import { CloudVpsSection } from './components/CloudVpsSection';
import { DedicatedBareMetal } from './components/DedicatedBareMetal';
import { HowItWorksSteps } from './components/HowItWorksSteps';
import { WhyChooseUs } from './components/WhyChooseUs';
import { DigitalServicesGrid } from './components/DigitalServicesGrid';
import { GlobalInfrastructure } from './components/GlobalInfrastructure';
import { IndustriesAndReviews } from './components/IndustriesAndReviews';
import { FreeMigrationSection } from './components/FreeMigrationSection';
import { FaqSection } from './components/FaqSection';
import { CartCheckoutModal } from './components/CartCheckoutModal';
import { LiveChatDrawer } from './components/LiveChatDrawer';
import { VideoTourModal } from './components/VideoTourModal';
import { DomainSearchModal } from './components/DomainSearchModal';
import { FloatingActions } from './components/FloatingActions';

export default function App() {
  const [currency, setCurrency] = useState<Currency>('INR');

  // Modal & Drawer States
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [selectedPlanName, setSelectedPlanName] = useState('Business');
  const [selectedPlanPrice, setSelectedPlanPrice] = useState(199.99);
  const [selectedBillingCycle, setSelectedBillingCycle] = useState<BillingCycle>('48months');

  const [liveChatOpen, setLiveChatOpen] = useState(false);
  const [videoTourOpen, setVideoTourOpen] = useState(false);
  const [domainSearchOpen, setDomainSearchOpen] = useState(false);

  const handleOpenCheckout = (
    planName: string,
    price: number,
    cycle: BillingCycle = '48months'
  ) => {
    setSelectedPlanName(planName);
    setSelectedPlanPrice(price);
    setSelectedBillingCycle(cycle);
    setCheckoutModalOpen(true);
  };

  const handleSelectService = (serviceName: string) => {
    if (serviceName.includes('Domain')) {
      setDomainSearchOpen(true);
    } else if (serviceName.includes('Web Hosting') || serviceName.includes('Hosting')) {
      const el = document.getElementById('hosting-plans');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (serviceName.includes('VPS')) {
      const el = document.getElementById('cloud-vps');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else {
      const el = document.getElementById('digital-services');
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#faf8fd] text-slate-900 font-sans selection:bg-[#9810fa] selection:text-white">
      {/* Note: Header & Footer removed as per user instruction ("Don't include header & footer") */}

      <main>
        {/* 1. Hero Section with Auto Multi-Color Left Title & 11-Service Strip */}
        <HeroSection
          currency={currency}
          onOpenCheckout={handleOpenCheckout}
          onOpenDomainSearch={() => setDomainSearchOpen(true)}
          onSelectService={handleSelectService}
        />

        {/* 2. Speed-Optimized NVMe Web Hosting Plans (Matching Attached Image with 48mo Selector) */}
        <HostingPlans currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 3. 3 Spotlight Feature Cards */}
        <PillarCards currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 4. Choose Your Cloud Architecture & cPanel Suite */}
        <ArchitectureTabs currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 5. Transparent Price Comparison */}
        <PriceComparison currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 6. High-Performance Cloud VPS */}
        <CloudVpsSection currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 7. Enterprise Dedicated Servers & Bare Metal */}
        <DedicatedBareMetal currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 8. How It Works - Under 3 Minutes */}
        <HowItWorksSteps />

        {/* 9. Why Choose Gitysoft & Data Center Tour */}
        <WhyChooseUs
          onOpenVideoTour={() => setVideoTourOpen(true)}
          onOpenLiveChat={() => setLiveChatOpen(true)}
        />

        {/* 10. Complete Digital Growth Ecosystem Grid */}
        <DigitalServicesGrid
          currency={currency}
          onOpenCheckout={handleOpenCheckout}
          onOpenDomainSearch={() => setDomainSearchOpen(true)}
        />

        {/* 11. Global Infrastructure & Datacenter Edge Network */}
        <GlobalInfrastructure onOpenCheckout={handleOpenCheckout} />

        {/* 12. Highly Responsive Customer Reviews with Trustpilot & Clutch Badges */}
        <IndustriesAndReviews />

        {/* 13. Free Website Migration Cyber Card (Matching Attached Screenshot) */}
        <FreeMigrationSection
          onGetStarted={() => handleOpenCheckout('Free Website Migration (Zero Downtime)', 0)}
        />

        {/* 14. Frequently Asked Questions with Multi-Tabs Categorized Contents & Search */}
        <FaqSection
          onOpenLiveChat={() => setLiveChatOpen(true)}
          onOpenEmailSupport={() => setLiveChatOpen(true)}
        />
      </main>

      {/* Interactive Global Modals and Drawers */}
      <CartCheckoutModal
        isOpen={checkoutModalOpen}
        onClose={() => setCheckoutModalOpen(false)}
        planName={selectedPlanName}
        basePrice={selectedPlanPrice}
        initialCycle={selectedBillingCycle}
        currency={currency}
      />

      <LiveChatDrawer
        isOpen={liveChatOpen}
        onClose={() => setLiveChatOpen(false)}
        onSelectPlan={handleOpenCheckout}
      />

      <VideoTourModal
        isOpen={videoTourOpen}
        onClose={() => setVideoTourOpen(false)}
      />

      <DomainSearchModal
        isOpen={domainSearchOpen}
        onClose={() => setDomainSearchOpen(false)}
        currency={currency}
        onSelectDomain={(domain, price) => handleOpenCheckout(`Domain: ${domain}`, price)}
      />

      {/* Floating Action Buttons (Back to Top only) */}
      <FloatingActions />
    </div>
  );
}
