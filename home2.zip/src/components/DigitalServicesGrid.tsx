import React, { useState } from 'react';
import { Currency } from '../types';
import {
  TrendingUp,
  MessageSquare,
  Compass,
  Zap,
  Globe,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Smartphone,
  Layers,
  BarChart3,
  Search,
} from 'lucide-react';

interface DigitalServicesGridProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number) => void;
  onOpenDomainSearch: () => void;
}

export const DigitalServicesGrid: React.FC<DigitalServicesGridProps> = ({
  currency,
  onOpenCheckout,
  onOpenDomainSearch,
}) => {
  const [transferDomainInput, setTransferDomainInput] = useState('');
  const [transferStatus, setTransferStatus] = useState<string | null>(null);

  const handleDomainTransferCheck = () => {
    if (!transferDomainInput.trim()) return;
    setTransferStatus('Checking registry transfer lock...');
    setTimeout(() => {
      setTransferStatus(`Eligible for ₹0 Free Transfer: ${transferDomainInput}`);
    }, 600);
  };

  return (
    <section id="digital-services" className="py-20 bg-slate-50/50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" /> Full-Stack Digital Agency
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 leading-tight">
            Complete Digital Growth Ecosystem
          </h2>
          <p className="mt-3 text-base text-slate-600">
            From high-speed hosting and domain management to bulk communications and custom web engineering.
          </p>
        </div>

        {/* 6 Cards Grid matching Screenshot 2 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {/* Card 1: Digital Marketing That Gets Results */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-extrabold text-slate-900 leading-snug">
                  Digital Marketing <br /> That Gets Results
                </h3>
                {/* Social icons */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="w-6 h-6 rounded-full bg-purple-50 text-[#9810fa] flex items-center justify-center text-[10px] font-bold border border-purple-200">
                    G
                  </span>
                  <span className="w-6 h-6 rounded-full bg-pink-50 text-pink-600 flex items-center justify-center text-[10px] font-bold border border-pink-200">
                    📷
                  </span>
                  <span className="w-6 h-6 rounded-full bg-[#9810fa] text-white flex items-center justify-center text-[10px] font-bold">
                    f
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center my-6">
                <div className="space-y-2 text-xs text-slate-700">
                  {[
                    'SEO | SMO | PPC',
                    'Google My Business',
                    'Social Media Marketing',
                    'Content Marketing',
                  ].map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="font-medium">{feat}</span>
                    </div>
                  ))}
                </div>

                {/* Growth Chart Illustration */}
                <div className="bg-slate-50 rounded-2xl p-3 border border-slate-200 flex items-end justify-center gap-2 h-24">
                  <div className="w-3 bg-blue-300 rounded-t h-8" />
                  <div className="w-3 bg-blue-400 rounded-t h-12" />
                  <div className="w-3 bg-indigo-500 rounded-t h-16" />
                  <div className="w-3 bg-purple-600 rounded-t h-20 relative">
                    <span className="w-2 h-2 rounded-full bg-pink-500 absolute -top-1 left-0.5" />
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => onOpenCheckout('Digital Marketing Growth Pack', 3999)}
              className="w-full sm:w-auto py-2.5 px-5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs tracking-wide shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              Grow Your Business <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 2: Bulk SMS & WhatsApp */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-extrabold text-slate-900 leading-snug">
                Bulk SMS & WhatsApp
              </h3>
              <p className="text-xs text-slate-500 mt-1 mb-4">Reach More Customers</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center my-4">
                <div className="space-y-2 text-xs text-slate-700">
                  {[
                    'Promotional & Transactional',
                    'OTP & Alerts',
                    'DLT Registration Support',
                    'Developer API',
                  ].map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="font-medium">{feat}</span>
                    </div>
                  ))}
                </div>

                {/* WhatsApp Chat Simulation */}
                <div className="bg-emerald-50 rounded-2xl p-2.5 border border-emerald-200 flex flex-col justify-between text-[10px]">
                  <div className="flex items-center gap-1.5 text-emerald-800 font-bold border-b border-emerald-200/80 pb-1">
                    <Smartphone className="w-3 h-3 text-emerald-600" /> WhatsApp Chat
                  </div>
                  <div className="bg-white p-2 rounded-lg my-1.5 shadow-xs text-slate-700 border border-emerald-100">
                    <div className="font-bold text-[9px] text-emerald-700">Flash Sale: 50% Off!</div>
                    <div className="text-[9px] text-slate-500 mt-0.5">Coupon Code: GITGW</div>
                  </div>
                  <span className="text-[9px] text-emerald-700 font-semibold text-right">99.8% Delivery</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onOpenCheckout('Bulk WhatsApp & SMS Bundle', 999)}
              className="w-full sm:w-auto py-2.5 px-5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs tracking-wide shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              Start Messaging <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 3: Complete Digital Solutions Under One Roof */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-extrabold text-slate-900 leading-snug">
                Complete Digital Solutions Under One Roof
              </h3>
              <p className="text-xs text-slate-500 mt-1 mb-6">Everything you need to grow your brand.</p>

              {/* 4-Stage Plan-Build-Grow-Scale Roadmap (Screenshot 2) */}
              <div className="my-6">
                <div className="flex items-center justify-between relative">
                  <div className="absolute left-4 right-4 top-1/2 -translate-y-1/2 h-0.5 bg-slate-200 z-0" />
                  {[
                    { label: 'Plan', icon: '📄', color: 'bg-emerald-500 text-white' },
                    { label: 'Build', icon: '🔧', color: 'bg-[#9810fa] text-white' },
                    { label: 'Grow', icon: '🚀', color: 'bg-purple-600 text-white' },
                    { label: 'Scale', icon: '📊', color: 'bg-pink-600 text-white' },
                  ].map((step, sIdx) => (
                    <div key={sIdx} className="relative z-10 flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full ${step.color} flex items-center justify-center text-xs shadow-md`}>
                        {step.icon}
                      </div>
                      <span className="text-[11px] font-bold text-slate-700 mt-1.5">{step.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={() => onOpenCheckout('Full Digital Architecture Consultation', 1999)}
              className="w-full sm:w-auto py-2.5 px-5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs tracking-wide shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              Explore All Services <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 4: Go Online In Minutes */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-4 mb-4">
                <img
                  src="/src/assets/images/support_team_woman_1793935098144.jpg"
                  alt="Go Online with Gitysoft"
                  className="w-16 h-16 rounded-2xl object-cover shadow-md border border-slate-200 shrink-0"
                />
                <div>
                  <h3 className="text-xl font-extrabold text-slate-900 leading-snug">Go Online In Minutes</h3>
                  <p className="text-xs text-slate-500 mt-0.5">Launch your website with powerful tools and one-click setup.</p>
                </div>
              </div>

              <div className="my-6">
                <button
                  onClick={() => onOpenCheckout('Quick Launch Web Package', 499)}
                  className="py-2.5 px-5 rounded-xl bg-[#9810fa] hover:bg-[#820cd6] text-white font-bold text-xs tracking-wide shadow-md shadow-[#9810fa]/20 transition-all active:scale-95 flex items-center gap-2 mb-4"
                >
                  Start Building <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center gap-2 text-[10px]">
              <span className="text-slate-500 font-semibold">Supports:</span>
              <span className="px-2 py-0.5 rounded bg-purple-50 text-[#820cd6] font-bold border border-purple-200">
                WordPress
              </span>
              <span className="px-2 py-0.5 rounded bg-purple-50 text-purple-700 font-bold border border-purple-200">
                WooCommerce
              </span>
              <span className="px-2 py-0.5 rounded bg-orange-50 text-orange-700 font-bold border border-orange-200">
                HTML5
              </span>
              <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 font-bold border border-rose-200">
                Laravel
              </span>
            </div>
          </div>

          {/* Card 5: Turn Ideas into Powerful Websites */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-extrabold text-slate-900 leading-snug">
                Turn Ideas <span className="text-[#9810fa] font-black">into</span> Powerful Websites
              </h3>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                Create stunning websites with modern tools, templates and AI assistance.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center my-4">
                <div className="space-y-2 text-xs text-slate-700">
                  {['1000+ Templates', 'No Coding Required', 'Mobile Responsive'].map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="font-medium">{feat}</span>
                    </div>
                  ))}
                </div>

                {/* Templates preview mockup */}
                <div className="bg-slate-100 rounded-2xl p-2.5 border border-slate-200 flex flex-col gap-1.5 shadow-inner">
                  <div className="w-full h-8 bg-blue-200 rounded-lg flex items-center justify-center text-[10px] text-blue-800 font-bold">
                    Hero Banner
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    <div className="h-6 bg-slate-200 rounded" />
                    <div className="h-6 bg-slate-200 rounded" />
                  </div>
                  <span className="text-[9px] text-slate-400 italic text-right">Beautiful templates</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onOpenCheckout('AI Website Builder Pro', 299)}
              className="w-full sm:w-auto py-2.5 px-5 rounded-xl bg-[#9810fa] hover:bg-[#820cd6] text-white font-bold text-xs tracking-wide shadow-md shadow-[#9810fa]/20 transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              Create Your Website <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 6: Domain Transfer */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-xl font-extrabold text-slate-900 leading-snug">Domain Transfer</h3>
                  <p className="text-xs text-slate-500 mt-1">Move your domain to Gitysoft easily and securely.</p>
                </div>
                {/* Globe Graphic (Screenshot 2) */}
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-white shadow-md shrink-0">
                  <Globe className="w-6 h-6 animate-spin-slow" />
                </div>
              </div>

              <div className="space-y-2 my-5 text-xs text-slate-700">
                {['Free Transfer Assistance', 'Zero Service Interruption', 'Quick & Easy Process'].map(
                  (feat, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="font-medium">{feat}</span>
                    </div>
                  )
                )}
              </div>

              {/* Quick interactive domain transfer input */}
              <div className="flex items-center gap-2 mb-4">
                <input
                  type="text"
                  placeholder="yourbrand.com"
                  value={transferDomainInput}
                  onChange={(e) => setTransferDomainInput(e.target.value)}
                  className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs outline-hidden focus:border-[#9810fa]"
                />
                <button
                  onClick={handleDomainTransferCheck}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800"
                >
                  Verify
                </button>
              </div>
              {transferStatus && (
                <div className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 p-2 rounded-lg border border-emerald-200 mb-3">
                  {transferStatus}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => onOpenDomainSearch()}
                className="py-2.5 px-5 rounded-xl bg-[#9810fa] hover:bg-[#820cd6] text-white font-bold text-xs tracking-wide shadow-md shadow-[#9810fa]/20 transition-all active:scale-95 flex items-center gap-2"
              >
                Transfer Domain <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <span className="text-xs font-bold text-emerald-600 font-mono">₹0 Transfer Fee</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
