import React, { useState } from 'react';
import {
  Zap,
  Shield,
  Headphones,
  Sliders,
  Play,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Activity,
  HardDrive,
  Cpu,
  ArrowRight,
  Server,
} from 'lucide-react';

interface WhyChooseUsProps {
  onOpenVideoTour: () => void;
  onOpenLiveChat: () => void;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ onOpenVideoTour, onOpenLiveChat }) => {
  const [activeTab, setActiveTab] = useState('features');
  const [openAccordion, setOpenAccordion] = useState<number>(0);

  const tabs = [
    { id: 'features', label: 'Features', icon: Zap },
    { id: 'performance', label: 'Performance', icon: Activity },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'support', label: 'Support', icon: Headphones },
    { id: 'technology', label: 'Technology', icon: Sliders },
  ];

  const accordionItems = [
    {
      num: '01',
      title: 'Blazing Fast Infrastructure',
      subtitle: 'Powered by NVMe SSD storage, LiteSpeed, and global data centers for unmatched speed and reliability.',
      pills: ['Gen4 NVMe 7000MB/s', 'LiteSpeed Web Server', 'Sub-5ms India Latency', 'HTTP/3 & QUIC Enabled'],
    },
    {
      num: '02',
      title: 'Enterprise Grade Security Layer',
      subtitle: 'Multi-layer active defense with Imunify360, Corero 3.2 Tbps DDoS mitigation, and automatic web application firewall rules.',
      pills: ['Hardware Firewall', 'Zero-Day Patching', '256-Bit SSL', 'DDoS Shield'],
    },
    {
      num: '03',
      title: '24/7 Expert Support & Automated Backups',
      subtitle: 'Instant responses from certified Linux sysadmins and database engineers, backed by JetBackup cloud snapshots.',
      pills: ['< 5 Min Reply', 'Real Engineers', 'JetBackup Snapshots', 'Free Site Restores'],
    },
    {
      num: '04',
      title: 'Global Data Centers & Scalability',
      subtitle: 'Carrier-neutral facilities in Mumbai, Singapore, Frankfurt, and Virginia with redundant power grids and dual 10Gbps uplinks.',
      pills: ['Mumbai Tier-4', 'N+1 Diesel UPS', 'Anycast Routing', 'Dual 10G Uplinks'],
    },
    {
      num: '05',
      title: 'Flexible & Scalable Solutions',
      subtitle: 'Instant resource scaling with zero downtime. Upgrade RAM, CPU, and NVMe arrays on demand without migrations.',
      pills: ['Zero Downtime Scale', 'Transparent Billing', 'REST API Access', 'Custom OS Stacks'],
    },
  ];

  return (
    <section id="why-choose" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Navigation Tabs matching Screenshot 1 & 5 */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-12 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 sm:px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold flex items-center gap-2 transition-all shrink-0 ${
                  isActive
                    ? 'bg-[#9810fa] text-white shadow-md shadow-[#9810fa]/25'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* 2-Column Section Content (Screenshot 1 & 5) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Data Center Tour Card & Metrics */}
          <div className="lg:col-span-5 space-y-6">
            {/* Interactive Inside Gitysoft Data Center Video Card (Screenshot 5) */}
            <div className="relative rounded-3xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl group">
              <img
                src="/src/assets/images/datacenter_server_room_1793935095545.jpg"
                alt="Inside Gitysoft Tier-4 Data Center"
                className="w-full h-72 sm:h-80 object-cover opacity-60 group-hover:scale-105 group-hover:opacity-75 transition-all duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent p-6 sm:p-7 flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-[#9810fa]/90 text-white shadow-xs backdrop-blur-xs flex items-center gap-1.5">
                    ✦ Take a Tour
                  </span>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-mono text-emerald-400 bg-slate-950/80 border border-emerald-500/40">
                    Tier-4 Mumbai
                  </span>
                </div>

                {/* Center Play Button Overlay */}
                <button
                  onClick={onOpenVideoTour}
                  className="w-16 h-16 rounded-full bg-white/90 hover:bg-white text-[#9810fa] flex items-center justify-center self-center shadow-2xl transition-transform active:scale-95 group-hover:scale-110"
                  aria-label="Play video tour"
                >
                  <Play className="w-7 h-7 fill-blue-600 ml-1" />
                </button>

                <div>
                  <h3 className="text-xl sm:text-2xl font-black text-white leading-tight">
                    Inside Gitysoft Data Center
                  </h3>
                  <p className="text-xs text-slate-300 mt-1 mb-3">
                    See how we power businesses across the globe with next-gen infrastructure.
                  </p>
                  <button
                    onClick={onOpenVideoTour}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold backdrop-blur-md transition-colors"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" /> Watch Video
                  </button>
                </div>
              </div>
            </div>

            {/* Why Choose Gitysoft Text & 3 Key Stats (Screenshot 1) */}
            <div className="p-6 rounded-3xl bg-slate-50 border border-slate-200">
              <h3 className="text-2xl font-black text-slate-900 mb-2">Why Choose Gitysoft?</h3>
              <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                We combine technology, expertise, and dedicated support to help you grow without limits.
              </p>

              <button
                onClick={onOpenLiveChat}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#9810fa] hover:bg-[#820cd6] text-white text-xs font-bold shadow-md shadow-[#9810fa]/20 transition-all active:scale-95 mb-6"
              >
                Learn More About Us <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="grid grid-cols-3 gap-3 pt-4 border-t border-slate-200 text-center">
                <div>
                  <div className="text-lg font-black text-slate-900 font-mono">99.99%</div>
                  <div className="text-[10px] text-slate-500 font-semibold mt-0.5">Uptime SLA</div>
                </div>
                <div>
                  <div className="text-lg font-black text-[#9810fa] font-mono">&lt; 5 Min</div>
                  <div className="text-[10px] text-slate-500 font-semibold mt-0.5">SysAdmin Reply</div>
                </div>
                <div>
                  <div className="text-lg font-black text-purple-600 font-mono">Tier-4</div>
                  <div className="text-[10px] text-slate-500 font-semibold mt-0.5">Mumbai DC</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Accordion with Live NVMe Throughput Gauge (Screenshot 1 & 5) */}
          <div className="lg:col-span-7 space-y-4">
            {accordionItems.map((item, idx) => {
              const isOpen = openAccordion === idx;
              return (
                <div
                  key={idx}
                  className={`rounded-2xl border transition-all duration-200 ${
                    isOpen ? 'border-purple-400 bg-white shadow-lg' : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <button
                    onClick={() => setOpenAccordion(isOpen ? -1 : idx)}
                    className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-black font-mono px-2.5 py-1 rounded-lg bg-purple-50 text-[#820cd6] border border-purple-200">
                        {item.num}
                      </span>
                      <h4 className="text-sm sm:text-base font-extrabold text-slate-900">{item.title}</h4>
                    </div>
                    <div className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 shrink-0">
                      {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-6 pt-1 text-xs text-slate-600 space-y-4 border-t border-slate-100 animate-in fade-in duration-150">
                      <p className="leading-relaxed">{item.subtitle}</p>

                      {/* Feature Pills */}
                      <div className="flex flex-wrap gap-2">
                        {item.pills.map((pill, pIdx) => (
                          <span
                            key={pIdx}
                            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-50 text-blue-800 text-[11px] font-semibold border border-purple-200/80"
                          >
                            <CheckCircle2 className="w-3 h-3 text-[#9810fa]" />
                            {pill}
                          </span>
                        ))}
                      </div>

                      {/* Interactive Blade Telemetry Card (Screenshot 1 & 5) */}
                      <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800 text-white font-mono text-xs shadow-inner">
                        <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-[11px]">
                          <div className="flex items-center gap-2">
                            <span className="text-blue-400 font-bold">NVMe</span>
                            <span className="text-[10px] bg-purple-900/60 text-blue-200 px-1.5 rounded">GEN4 SSD</span>
                          </div>
                          <span className="text-emerald-400 font-bold flex items-center gap-1 text-[10px]">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> ONLINE
                          </span>
                        </div>

                        <div className="py-3">
                          <div className="flex justify-between text-[11px] mb-1">
                            <span className="text-slate-400">Throughput:</span>
                            <span className="text-cyan-400 font-bold">7,500 MB/s</span>
                          </div>
                          <div className="w-full bg-slate-800 rounded-full h-2">
                            <div className="bg-gradient-to-r from-blue-500 to-cyan-400 h-2 rounded-full" style={{ width: '92%' }} />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/80 text-[10px]">
                          <div>
                            <span className="text-slate-400">Array Integrity:</span>
                            <span className="text-emerald-400 font-bold ml-1">100% RAID-10</span>
                          </div>
                          <div className="text-right">
                            <span className="text-slate-400">Ultra Resilient:</span>
                            <span className="text-purple-400 font-bold ml-1">0.02ms I/O</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
