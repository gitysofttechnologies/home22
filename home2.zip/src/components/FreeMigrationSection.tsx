import React from 'react';
import { Sparkles, ArrowRight, Headphones, CheckCircle2 } from 'lucide-react';

interface FreeMigrationSectionProps {
  onGetStarted?: () => void;
}

export const FreeMigrationSection: React.FC<FreeMigrationSectionProps> = ({ onGetStarted }) => {
  return (
    <section id="free-migration" className="py-8 sm:py-12 bg-[#faf8fd]">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Dark Cyber Midnight Card with No Side Borders */}
        <div
          className="relative bg-gradient-to-b from-[#0b061d] via-[#080415] to-[#05020e] text-center px-8 sm:px-14 py-8 sm:py-11 overflow-hidden shadow-2xl transition-all duration-300"
          style={{
            clipPath:
              'polygon(clamp(46px, 7vw, 78px) 0%, 100% 0%, 100% calc(100% - clamp(46px, 7vw, 78px)), calc(100% - clamp(46px, 7vw, 78px)) 100%, 0% 100%, 0% clamp(46px, 7vw, 78px))',
          }}
        >
          {/* Subtle ambient purple glow in background */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[450px] h-[220px] bg-[#9810fa]/15 blur-[80px] rounded-full pointer-events-none" />

          {/* Tag / Category Badge */}
          <div className="relative z-10 inline-flex items-center gap-2 text-[#d4a8ff] text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-2.5">
            <Sparkles className="w-3.5 h-3.5 text-[#c084fc]" />
            <span>CERTIFIED LINUX SYSADMINS &amp; GITYSOFT AI AGENT</span>
          </div>

          {/* Main Headline */}
          <h2 className="relative z-10 text-2xl sm:text-4xl lg:text-[42px] font-black text-white tracking-tight leading-tight mb-2.5">
            Free Website Migration
          </h2>

          {/* Subtitle with Exact Copy from Screenshot */}
          <p className="relative z-10 text-slate-300/90 text-xs sm:text-sm md:text-[15px] leading-relaxed max-w-xl mx-auto mb-5 sm:mb-6 font-normal">
            Move your Website Free from another Hosting Provider to
            <br />
            Gitysoft.Our Team will migrate Fre of cost
          </p>

          {/* Glowing CTA Button */}
          <div className="relative z-10 mb-5 sm:mb-6">
            <button
              onClick={onGetStarted}
              className="group inline-flex items-center justify-center gap-2 px-7 sm:px-8 py-2.5 sm:py-3 rounded-full bg-gradient-to-r from-[#8710f5] to-[#9810fa] hover:from-[#780cd9] hover:to-[#890de2] text-white font-bold text-xs sm:text-sm shadow-[0_0_24px_rgba(152,16,250,0.6)] hover:shadow-[0_0_35px_rgba(152,16,250,0.85)] transition-all duration-300 active:scale-95 cursor-pointer"
            >
              <span>Get started</span>
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* Bottom Feature Badges */}
          <div className="relative z-10 flex flex-wrap items-center justify-center gap-5 sm:gap-8 text-[11px] sm:text-xs text-slate-300 font-medium">
            {/* 24x7 Round-the-Clock Priority Support */}
            <div className="inline-flex items-center gap-2">
              <Headphones className="w-3.5 h-3.5 text-[#b280fc] shrink-0" />
              <span>24x7 Round-the-Clock Priority Support</span>
            </div>

            {/* Instant automated setup */}
            <div className="inline-flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981] shrink-0" />
              <span>Instant automated setup in &lt; 45s</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
