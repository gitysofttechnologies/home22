import React, { useState, useRef } from 'react';
import { ATTACHED_IMAGE_PLANS, ImagePricingPlan } from '../data/hostingData';
import { BillingCycle, Currency, PlanTerm } from '../types';
import {
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Gift,
  HelpCircle,
  Sparkles,
  Bot,
  Globe,
  ShoppingBag,
  Cpu,
} from 'lucide-react';

interface HostingPlansProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number, cycle: BillingCycle) => void;
}

export const HostingPlans: React.FC<HostingPlansProps> = ({ currency, onOpenCheckout }) => {
  const [selectedTerm, setSelectedTerm] = useState<PlanTerm>('48');
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [activeMobileIdx, setActiveMobileIdx] = useState(0);
  const [activeTooltipKey, setActiveTooltipKey] = useState<string | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const toggleTooltip = (key: string) => {
    setActiveTooltipKey((prev) => (prev === key ? null : key));
  };

  const termLabels: Record<PlanTerm, { label: string; discountText: string }> = {
    '48': { label: '48 months plan', discountText: 'Best value • Save up to 85%' },
    '24': { label: '24 months plan', discountText: 'Save up to 80%' },
    '12': { label: '12 months plan', discountText: 'Save up to 75%' },
    '1': { label: '1 month plan', discountText: 'Standard monthly' },
  };

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -340 : 340;
      scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const scrollToPlan = (index: number) => {
    const safeIdx = Math.max(0, Math.min(index, ATTACHED_IMAGE_PLANS.length - 1));
    setActiveMobileIdx(safeIdx);
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const card = container.children[safeIdx] as HTMLElement;
      if (card) {
        card.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
      }
    }
  };

  const handleMobileScroll = () => {
    if (scrollContainerRef.current && window.innerWidth < 768) {
      const container = scrollContainerRef.current;
      const scrollLeft = container.scrollLeft;
      const itemWidth = container.offsetWidth;
      if (itemWidth > 0) {
        const index = Math.round(scrollLeft / itemWidth);
        if (index >= 0 && index < ATTACHED_IMAGE_PLANS.length && index !== activeMobileIdx) {
          setActiveMobileIdx(index);
        }
      }
    }
  };

  const mapTermToCycle = (term: PlanTerm): BillingCycle => {
    if (term === '48') return '48months';
    if (term === '24') return '24months';
    if (term === '12') return 'yearly';
    return 'monthly';
  };

  return (
    <section id="hosting-plans" className="py-20 bg-[#faf8fc] border-b border-purple-100/80 relative overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[500px] bg-[#9810fa]/5 blur-3xl rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Modern Center-Aligned Header for Pricing Plans (User Request) */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-tight">
            Choose Your{' '}
            <span className="bg-gradient-to-r from-[#9810fa] via-purple-600 to-indigo-600 bg-clip-text text-transparent">
              Hosting Plan
            </span>
          </h2>
          <p className="mt-3.5 text-sm sm:text-base text-slate-600 max-w-2xl mx-auto leading-relaxed">
            All plans feature Gen4 NVMe LiteSpeed storage, 1 year free domain, lifetime free SSL, and round-the-clock 24x7hrs Technical Assistance.
          </p>
        </div>

        {/* Top Control Bar with 48 months dropdown & Navigation Arrows */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8 pb-2">
          <div className="hidden sm:block sm:w-28" />

          {/* Centered Term Selector Dropdown matching attached image */}
          <div className="relative inline-block text-left">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="inline-flex items-center gap-2.5 px-6 py-2.5 rounded-full bg-white border border-slate-300 hover:border-[#9810fa] text-slate-800 text-sm font-bold shadow-xs hover:shadow-md transition-all cursor-pointer focus:outline-hidden"
              aria-expanded={dropdownOpen}
            >
              <span>{termLabels[selectedTerm].label}</span>
              <ChevronDown className={`w-4 h-4 text-slate-500 transition-transform ${dropdownOpen ? 'rotate-180 text-[#9810fa]' : ''}`} />
            </button>

            {dropdownOpen && (
              <div className="absolute left-1/2 -translate-x-1/2 mt-2 w-72 rounded-2xl bg-white border border-purple-100 shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                {(Object.keys(termLabels) as PlanTerm[]).map((term) => (
                  <button
                    key={term}
                    onClick={() => {
                      setSelectedTerm(term);
                      setDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
                      selectedTerm === term
                        ? 'bg-[#9810fa]/10 text-[#9810fa] font-bold'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <div className="text-slate-900 font-bold">{termLabels[term].label}</div>
                      <div className="text-[10px] text-slate-500">{termLabels[term].discountText}</div>
                    </div>
                    {selectedTerm === term && <Check className="w-4 h-4 text-[#9810fa]" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Arrow Controls matching attached image */}
          <div className="hidden sm:flex items-center gap-2">
            <button
              onClick={() => handleScroll('left')}
              className="w-9 h-9 rounded-full bg-white border border-slate-200 hover:border-[#9810fa] text-slate-600 hover:text-[#9810fa] flex items-center justify-center shadow-xs hover:shadow-sm transition-all cursor-pointer"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => handleScroll('right')}
              className="w-9 h-9 rounded-full bg-white border border-slate-200 hover:border-[#9810fa] text-slate-600 hover:text-[#9810fa] flex items-center justify-center shadow-xs hover:shadow-sm transition-all cursor-pointer"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
        {/* 4 Cards: Mobile 1/1 Snap Carousel & Desktop 4-Col Grid */}
        <div
          ref={scrollContainerRef}
          onScroll={handleMobileScroll}
          className="flex md:grid md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch overflow-x-auto md:overflow-visible pb-4 pt-2 snap-x snap-mandatory scrollbar-none"
        >
          {ATTACHED_IMAGE_PLANS.map((plan: ImagePricingPlan) => {
            const isHighlighted = plan.isPopular;
            const priceData = plan.prices[selectedTerm];
            const monthlyPrice = currency === 'USD' ? priceData.monthlyUSD : priceData.monthlyINR;
            const originalPrice = currency === 'USD' ? priceData.originalUSD : priceData.originalINR;
            const totalPrice = currency === 'USD' ? priceData.totalUSD : priceData.totalINR;
            const renewalPrice = currency === 'USD' ? priceData.renewalUSD : priceData.renewalINR;
            const currencySymbol = currency === 'USD' ? '$' : '₹';

            return (
              <div
                key={plan.id}
                className={`w-full min-w-full md:min-w-0 md:w-auto shrink-0 snap-center rounded-3xl flex flex-col justify-between transition-all duration-300 relative ${
                  isHighlighted
                    ? 'bg-[#120524] text-white border-2 border-[#9810fa] shadow-2xl ring-4 ring-[#9810fa]/20 md:-translate-y-1'
                    : 'bg-white text-slate-900 border border-slate-200 shadow-md hover:shadow-xl hover:border-slate-300'
                }`}
              >
                {/* Highlighted Banner / Discount Pill */}
                <div className="p-6 pb-0 flex items-start justify-between min-h-[44px]">
                  <div>
                    {isHighlighted ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-red-500 to-rose-600 text-white text-[11px] font-black tracking-wide shadow-sm">
                        Special offer • {plan.discountBadge}
                      </span>
                    ) : (
                      <span className="inline-block px-2.5 py-0.5 rounded-full bg-red-600 text-white text-[11px] font-black uppercase tracking-wider">
                        {plan.discountBadge}
                      </span>
                    )}
                  </div>
                </div>

                <div className="p-6 pt-2 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Plan Title & Description */}
                    <div className="mb-4">
                      <h3
                        className={`text-2xl font-black tracking-tight flex items-center gap-2 ${
                          isHighlighted ? 'text-white' : 'text-slate-900'
                        }`}
                      >
                        {isHighlighted && <Sparkles className="w-5 h-5 text-[#c084fc] fill-[#c084fc]" />}
                        {plan.name}
                      </h3>
                      <p
                        className={`text-xs mt-2 leading-relaxed min-h-[34px] ${
                          isHighlighted ? 'text-slate-300' : 'text-slate-600'
                        }`}
                      >
                        {plan.headline}
                      </p>
                    </div>

                    {/* Pricing Block matching attached image */}
                    <div className="mb-5">
                      <div
                        className={`text-xs line-through font-mono ${
                          isHighlighted ? 'text-slate-400' : 'text-slate-400'
                        }`}
                      >
                        {currencySymbol}
                        {originalPrice.toFixed(2)}
                      </div>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span
                          className={`text-4xl font-black font-mono tracking-tight ${
                            isHighlighted ? 'text-white' : 'text-slate-950'
                          }`}
                        >
                          {currencySymbol}
                          {monthlyPrice.toFixed(2)}
                        </span>
                        <span
                          className={`text-xs font-semibold ${
                            isHighlighted ? 'text-slate-300' : 'text-slate-500'
                          }`}
                        >
                          /mo
                        </span>
                      </div>

                      {/* Choose Plan Button */}
                      <button
                        onClick={() => onOpenCheckout(plan.name, monthlyPrice, mapTermToCycle(selectedTerm))}
                        className={`w-full mt-4 py-3 px-5 rounded-2xl font-extrabold text-sm tracking-wide transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2 ${
                          isHighlighted
                            ? 'bg-[#9810fa] hover:bg-[#820cd6] text-white shadow-lg shadow-[#9810fa]/40'
                            : 'bg-white border-2 border-[#9810fa] text-[#9810fa] hover:bg-[#9810fa] hover:text-white shadow-xs'
                        }`}
                      >
                        Choose plan
                      </button>

                      {/* Subtitle / Renewal Notice matching image */}
                      <p
                        className={`text-[11px] mt-3 leading-relaxed ${
                          isHighlighted ? 'text-slate-400' : 'text-slate-500'
                        }`}
                      >
                        Today you pay {currencySymbol}
                        {totalPrice.toFixed(2)} for {selectedTerm} months. Renews at {currencySymbol}
                        {renewalPrice.toFixed(2)}/mo for the same term. Cancel anytime.
                      </p>
                    </div>

                    {/* Free Domain + Canva Pro Bonus Promo Box with Tooltip (#9810fa background) */}
                    <div className="relative group/promo mb-6">
                      <div
                        onClick={() => toggleTooltip(`${plan.id}-promo`)}
                        className={`rounded-2xl p-3 flex items-center justify-between gap-3 border transition-all cursor-pointer ${
                          isHighlighted
                            ? 'bg-[#210940] border-[#9810fa]/40 text-white hover:border-[#9810fa]'
                            : 'bg-slate-50 border-slate-200 text-slate-800 hover:border-[#9810fa]/50'
                        }`}
                      >
                        <div className="text-xs">
                          <div className="font-extrabold flex items-center gap-1.5 underline decoration-dashed decoration-[#9810fa] underline-offset-2">
                            <span>{plan.promoBanner.title}</span>
                            <HelpCircle className="w-3.5 h-3.5 text-[#9810fa] shrink-0" />
                          </div>
                          <div
                            className={`text-[11px] mt-0.5 ${
                              isHighlighted ? 'text-purple-300' : 'text-slate-500'
                            }`}
                          >
                            {plan.promoBanner.description}
                          </div>
                        </div>
                        <div className="w-9 h-9 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                          <Gift className="w-5 h-5" />
                        </div>
                      </div>

                      {/* Tooltip contained strictly inside pricing plan area */}
                      <div
                        className={`transition-all duration-200 absolute top-full left-0 right-0 mt-2 z-40 ${
                          activeTooltipKey === `${plan.id}-promo`
                            ? 'opacity-100 pointer-events-auto'
                            : 'pointer-events-none opacity-0 group-hover/promo:opacity-100'
                        }`}
                      >
                        <div className="bg-[#9810fa] text-white p-3 rounded-2xl shadow-2xl shadow-[#9810fa]/40 border border-purple-200/40 text-xs">
                          <div className="flex items-center gap-1.5 font-black mb-1 text-white">
                            <Gift className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                            <span>Free Domain + Canva Pro</span>
                          </div>
                          <div className="text-[11px] leading-relaxed text-purple-100">
                            {plan.promoBanner.tooltip ||
                              'Get 1 Year Free Domain (.com/.in) plus 1 Year Canva Pro subscription on 24 & 48-month plans.'}
                          </div>
                          {/* Triangle arrow pointing up */}
                          <div className="w-2.5 h-2.5 bg-[#9810fa] rotate-45 absolute -top-1 left-6 border-l border-t border-purple-200/40" />
                        </div>
                      </div>
                    </div>

                    {/* Core Features List with Tooltip on Free Domain & Storage */}
                    <div className="space-y-2.5 text-xs mb-6">
                      {plan.features.map((feat, idx) => {
                        const isTargetFeature =
                          feat.tooltip !== undefined ||
                          feat.text.toLowerCase().includes('domain') ||
                          feat.text.toLowerCase().includes('storage');

                        const tooltipTitle = feat.text.toLowerCase().includes('domain')
                          ? 'Free Domain for 1 Year'
                          : feat.text.toLowerCase().includes('storage')
                          ? 'Enterprise NVMe Storage'
                          : feat.text;

                        const tooltipDesc =
                          feat.tooltip ||
                          (feat.text.toLowerCase().includes('domain')
                            ? 'Claim 1 year free .com, .in, .net or .org domain with WHOIS privacy & DNS protection.'
                            : 'Ultra-fast Gen4 NVMe Storage with RAID-10 redundancy for instantaneous loading.');

                        const tooltipKey = `${plan.id}-feat-${idx}`;

                        return (
                          <div key={idx} className="relative group/feature">
                            <div
                              onClick={() => isTargetFeature && toggleTooltip(tooltipKey)}
                              className="flex items-center gap-2.5"
                            >
                              {feat.included ? (
                                <Check
                                  className={`w-4 h-4 shrink-0 ${
                                    isHighlighted ? 'text-[#c084fc]' : 'text-emerald-600'
                                  }`}
                                />
                              ) : (
                                <span
                                  className={`w-4 text-center shrink-0 font-bold ${
                                    isHighlighted ? 'text-slate-600' : 'text-slate-300'
                                  }`}
                                >
                                  –
                                </span>
                              )}
                              <span
                                className={`${
                                  feat.included
                                    ? isHighlighted
                                      ? feat.highlight
                                        ? 'text-white font-extrabold'
                                        : 'text-slate-200'
                                      : feat.highlight
                                      ? 'text-slate-900 font-bold'
                                      : 'text-slate-700'
                                    : isHighlighted
                                    ? 'text-slate-500 line-through'
                                    : 'text-slate-400'
                                } ${
                                  isTargetFeature
                                    ? 'underline decoration-dotted decoration-[#9810fa] underline-offset-4 cursor-pointer font-medium'
                                    : 'underline decoration-dashed decoration-slate-400/60 underline-offset-4'
                                } inline-flex items-center gap-1.5`}
                              >
                                <span>{feat.text}</span>
                                {isTargetFeature && (
                                  <HelpCircle className="w-3 h-3 text-[#9810fa] shrink-0 opacity-80" />
                                )}
                              </span>
                            </div>

                            {/* Tooltip strictly inside the pricing plan card boundaries (#9810fa background) */}
                            {isTargetFeature && (
                              <div
                                className={`transition-all duration-200 absolute bottom-full left-0 right-0 mb-2 z-40 ${
                                  activeTooltipKey === tooltipKey
                                    ? 'opacity-100 pointer-events-auto'
                                    : 'pointer-events-none opacity-0 group-hover/feature:opacity-100'
                                }`}
                              >
                                <div className="bg-[#9810fa] text-white p-3 rounded-2xl shadow-2xl shadow-[#9810fa]/40 border border-purple-200/40 text-xs">
                                  <div className="flex items-center gap-1.5 font-black mb-1 text-white">
                                    <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                                    <span>{tooltipTitle}</span>
                                  </div>
                                  <div className="text-[11px] leading-relaxed text-purple-100">
                                    {tooltipDesc}
                                  </div>
                                  {/* Triangle arrow pointing down */}
                                  <div className="w-2.5 h-2.5 bg-[#9810fa] rotate-45 absolute -bottom-1 left-6 border-r border-b border-purple-200/40" />
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Build With Section */}
                    <div className="pt-4 border-t border-slate-200/40 mb-6">
                      <div
                        className={`text-xs font-black mb-3 ${
                          isHighlighted ? 'text-slate-300' : 'text-slate-800'
                        }`}
                      >
                        Build with:
                      </div>
                      <div className="space-y-2 text-xs">
                        {plan.buildWith.map((item, idx) => (
                          <div key={idx} className="flex items-center gap-2.5">
                            {item.included ? (
                              <div
                                className={`w-4 h-4 rounded-full flex items-center justify-center ${
                                  isHighlighted ? 'text-[#c084fc]' : 'text-slate-700'
                                }`}
                              >
                                {item.name.includes('AI') ? (
                                  <Bot className="w-3.5 h-3.5" />
                                ) : item.name.includes('WordPress') ? (
                                  <Globe className="w-3.5 h-3.5" />
                                ) : item.name.includes('store') ? (
                                  <ShoppingBag className="w-3.5 h-3.5" />
                                ) : (
                                  <Cpu className="w-3.5 h-3.5" />
                                )}
                              </div>
                            ) : (
                              <span
                                className={`w-4 text-center shrink-0 font-bold ${
                                  isHighlighted ? 'text-slate-600' : 'text-slate-300'
                                }`}
                              >
                                –
                              </span>
                            )}
                            <span
                              className={`${
                                item.included
                                  ? isHighlighted
                                    ? 'text-slate-200 font-medium'
                                    : 'text-slate-800 font-medium'
                                  : isHighlighted
                                  ? 'text-slate-500'
                                  : 'text-slate-400'
                              } underline decoration-dashed decoration-slate-400/60 underline-offset-4`}
                            >
                              {item.name}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Communicate & Grow Section with Tooltip on Webmail */}
                    <div className="pt-4 border-t border-slate-200/40 mb-4">
                      <div
                        className={`text-xs font-black mb-3 ${
                          isHighlighted ? 'text-slate-300' : 'text-slate-800'
                        }`}
                      >
                        Communicate &amp; grow:
                      </div>
                      <div className="space-y-2 text-xs">
                        {plan.communicateGrow.map((item, idx) => {
                          const isWebmail =
                            item.tooltip !== undefined ||
                            item.text.toLowerCase().includes('webmail') ||
                            item.text.toLowerCase().includes('mailbox');

                          const tooltipTitle = 'Professional Webmail';
                          const tooltipDesc =
                            item.tooltip ||
                            'Secure Webmail with spam protection, IMAP/SMTP support & mobile Gmail/Outlook sync.';

                          const tooltipKey = `${plan.id}-webmail-${idx}`;

                          return (
                            <div key={idx} className="relative group/webmail">
                              <div
                                onClick={() => isWebmail && toggleTooltip(tooltipKey)}
                                className="flex items-center gap-2.5"
                              >
                                {item.included ? (
                                  <Check
                                    className={`w-4 h-4 shrink-0 ${
                                      isHighlighted ? 'text-[#c084fc]' : 'text-emerald-600'
                                    }`}
                                  />
                                ) : (
                                  <span
                                    className={`w-4 text-center shrink-0 font-bold ${
                                      isHighlighted ? 'text-slate-600' : 'text-slate-300'
                                    }`}
                                  >
                                    –
                                  </span>
                                )}
                                <span
                                  className={`${
                                    item.included
                                      ? isHighlighted
                                        ? item.highlight
                                          ? 'text-white font-extrabold'
                                          : 'text-slate-200'
                                        : 'text-slate-800'
                                      : isHighlighted
                                      ? 'text-slate-500'
                                      : 'text-slate-400'
                                  } ${
                                    isWebmail
                                      ? 'underline decoration-dotted decoration-[#9810fa] underline-offset-4 cursor-pointer font-medium'
                                      : 'underline decoration-dashed decoration-slate-400/60 underline-offset-4'
                                  } inline-flex items-center gap-1.5`}
                                >
                                  <span>{item.text}</span>
                                  {isWebmail && (
                                    <HelpCircle className="w-3 h-3 text-[#9810fa] shrink-0 opacity-80" />
                                  )}
                                </span>
                              </div>

                              {/* Tooltip strictly inside the pricing plan card boundaries (#9810fa background) */}
                              {isWebmail && (
                                <div
                                  className={`transition-all duration-200 absolute bottom-full left-0 right-0 mb-2 z-40 ${
                                    activeTooltipKey === tooltipKey
                                      ? 'opacity-100 pointer-events-auto'
                                      : 'pointer-events-none opacity-0 group-hover/webmail:opacity-100'
                                  }`}
                                >
                                  <div className="bg-[#9810fa] text-white p-3 rounded-2xl shadow-2xl shadow-[#9810fa]/40 border border-purple-200/40 text-xs">
                                    <div className="flex items-center gap-1.5 font-black mb-1 text-white">
                                      <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                                      <span>{tooltipTitle}</span>
                                    </div>
                                    <div className="text-[11px] leading-relaxed text-purple-100">
                                      {tooltipDesc}
                                    </div>
                                    {/* Triangle arrow pointing down */}
                                    <div className="w-2.5 h-2.5 bg-[#9810fa] rotate-45 absolute -bottom-1 left-6 border-r border-b border-purple-200/40" />
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Why This Plan? Box on Highlighted Plan */}
                    {plan.whyThisPlan && (
                      <div
                        className={`rounded-2xl p-3.5 mt-4 text-xs ${
                          isHighlighted
                            ? 'bg-[#230944] border border-[#9810fa]/40 text-slate-200'
                            : 'bg-purple-50/60 border border-purple-100 text-purple-900'
                        }`}
                      >
                        <div className="font-extrabold text-[#c084fc] mb-1">{plan.whyThisPlan.title}</div>
                        <div className="text-[11px] leading-relaxed text-slate-300">{plan.whyThisPlan.text}</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Mobile Carousel Pagination Dots */}
        <div className="md:hidden flex items-center justify-center gap-2 mt-4">
          {ATTACHED_IMAGE_PLANS.map((p, idx) => (
            <button
              key={p.id}
              onClick={() => scrollToPlan(idx)}
              className={`transition-all rounded-full cursor-pointer ${
                activeMobileIdx === idx
                  ? 'w-7 h-2 bg-[#9810fa]'
                  : 'w-2 h-2 bg-purple-200 hover:bg-purple-300'
              }`}
              aria-label={`Go to ${p.name} plan`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
