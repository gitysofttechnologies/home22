import React, { useState } from 'react';
import { VPS_TIERS } from '../data/hostingData';
import { Currency, VpsTier } from '../types';
import { formatCurrency } from '../utils/pricing';
import {
  Users,
  Briefcase,
  Zap,
  Headphones,
  Shield,
  Award,
  Cpu,
  HardDrive,
  Radio,
  Check,
  Terminal,
  Activity,
  ArrowRight,
} from 'lucide-react';

interface CloudVpsSectionProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number) => void;
}

export const CloudVpsSection: React.FC<CloudVpsSectionProps> = ({ currency, onOpenCheckout }) => {
  const [selectedTier, setSelectedTier] = useState<number>(1);
  const [selectedOs, setSelectedOs] = useState<string>('Ubuntu 24.04');

  const currentTier: VpsTier = VPS_TIERS.find((t) => t.tierNumber === selectedTier) || VPS_TIERS[0];

  const osList = ['Ubuntu 24.04', 'Debian 12', 'AlmaLinux 9', 'Rocky Linux', 'Windows Server'];

  return (
    <section id="cloud-vps" className="py-20 bg-slate-50/70 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Trust KPI Strip matching Screenshot 13 */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 pb-16 border-b border-slate-200/80">
          {[
            { metric: '10,000+', label: 'Happy Customers', icon: Users, color: 'text-[#9810fa]' },
            { metric: '50+', label: 'Services & Solutions', icon: Briefcase, color: 'text-emerald-600' },
            { metric: '99.9%', label: 'Uptime Guarantee', icon: Zap, color: 'text-amber-500' },
            { metric: '24/7', label: 'Expert Support', icon: Headphones, color: 'text-indigo-600' },
            { metric: '5+ Years', label: 'of Trusted Experience', icon: Shield, color: 'text-purple-600' },
            { metric: '100%', label: 'Customer Satisfaction', icon: Award, color: 'text-rose-500' },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div key={idx} className="flex items-center gap-3 bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-xs">
                <div className={`w-9 h-9 rounded-xl bg-slate-50 flex items-center justify-center shrink-0 ${item.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-black text-slate-900 tracking-tight font-mono">{item.metric}</div>
                  <div className="text-[11px] text-slate-500 font-medium leading-tight">{item.label}</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Section Heading & Tier Switcher */}
        <div className="pt-16 pb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-2xl">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 leading-tight">
              High-Performance Cloud VPS{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                for Growing Apps
              </span>
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-600">
              Scalable virtual private servers powered by latest AMD EPYC processors, enterprise Gen4 NVMe arrays,
              and dedicated 10 Gbps uplinks with instant 55-second setup.
            </p>
          </div>

          {/* Cloud 1 - 4 Tiers Pills (Screenshot 13 right) */}
          <div className="flex items-center gap-1.5 bg-slate-900 p-1.5 rounded-full shrink-0">
            {[1, 2, 3, 4].map((num) => (
              <button
                key={num}
                onClick={() => setSelectedTier(num)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                  selectedTier === num ? 'bg-white text-slate-900 shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                Cloud {num}
              </button>
            ))}
          </div>
        </div>

        {/* VPS 2-Column Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Card: Active VPS Plan Details */}
          <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div className="flex items-center gap-2">
                  <h3 className="text-2xl font-black text-slate-900">{currentTier.name}</h3>
                  {currentTier.popularTag && (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-purple-100 text-blue-800">
                      {currentTier.popularTag}
                    </span>
                  )}
                </div>

                <div className="text-right">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-black text-slate-950 font-mono">
                      {formatCurrency(currentTier.monthlyPrice, currency)}
                    </span>
                    <span className="text-xs text-slate-500 font-semibold">/month</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] justify-end">
                    <span className="text-slate-400 line-through">
                      {formatCurrency(currentTier.originalPrice, currency)}
                    </span>
                    <span className="text-emerald-600 font-bold">{currentTier.discountBadge}</span>
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-500 mb-6">
                Dedicated cloud resources with zero overselling guarantee.
              </p>

              {/* 4 Specs Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
                  <div className="flex items-center gap-1.5 text-[#9810fa] text-xs font-bold uppercase mb-1">
                    <Cpu className="w-3.5 h-3.5" /> Processor
                  </div>
                  <div className="text-base font-black text-slate-900 font-mono">{currentTier.vcpu} vCore</div>
                </div>

                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
                  <div className="flex items-center gap-1.5 text-purple-600 text-xs font-bold uppercase mb-1">
                    <Activity className="w-3.5 h-3.5" /> Memory
                  </div>
                  <div className="text-base font-black text-slate-900 font-mono">{currentTier.ramGb} GB RAM</div>
                </div>

                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
                  <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-bold uppercase mb-1">
                    <HardDrive className="w-3.5 h-3.5" /> Storage
                  </div>
                  <div className="text-base font-black text-slate-900 font-mono">{currentTier.nvmeGb} GB NVMe</div>
                </div>

                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
                  <div className="flex items-center gap-1.5 text-indigo-600 text-xs font-bold uppercase mb-1">
                    <Radio className="w-3.5 h-3.5" /> Network
                  </div>
                  <div className="text-base font-black text-slate-900 font-mono">
                    {currentTier.bandwidthMbps} Mbps
                  </div>
                </div>
              </div>

              {/* OS Selection */}
              <div className="mb-6">
                <label className="text-xs font-bold text-slate-700 block mb-2">
                  Choose Operating System (Pre-installed):
                </label>
                <div className="flex flex-wrap gap-2">
                  {osList.map((os) => (
                    <button
                      key={os}
                      onClick={() => setSelectedOs(os)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        selectedOs === os
                          ? 'bg-slate-900 text-white shadow-sm'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {os}
                    </button>
                  ))}
                </div>
              </div>

              {/* Feature Checklist */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 mb-6 text-xs text-slate-700">
                {currentTier.features.map((feat, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3" />
                    </div>
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => onOpenCheckout(`${currentTier.name} (${selectedOs})`, currentTier.monthlyPrice)}
              className="w-full py-3.5 px-4 rounded-xl bg-[#9810fa] hover:bg-[#820cd6] text-white font-bold text-xs sm:text-sm tracking-wide shadow-md shadow-[#9810fa]/20 transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              Deploy {currentTier.name} on {selectedOs} <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Right Card: Terminal Live Monitor (Screenshot 13) */}
          <div className="lg:col-span-5 bg-slate-950 rounded-3xl p-6 border border-slate-800 text-white shadow-2xl flex flex-col justify-between font-mono">
            <div>
              {/* Terminal Title Bar */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-800 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                  <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
                  <span className="w-2.5 h-2.5 rounded-full bg-green-500" />
                  <span className="text-slate-400 text-[11px] ml-2">vps-node@gitysoft-mumbai</span>
                </div>
                <span className="text-[10px] bg-emerald-950/80 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded-full flex items-center gap-1 font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> LIVE MONITOR
                </span>
              </div>

              {/* Terminal Body */}
              <div className="py-6 space-y-3 text-xs leading-relaxed">
                <div className="text-slate-500 text-[11px]">
                  // Initializing server cluster telemetry on {selectedOs}
                </div>
                <div className="text-blue-400">
                  &gt; gitysoft-cloud@core:~# vps provision --tier vps{selectedTier} --nvme
                </div>
                <div className="text-slate-300">
                  &gt;&gt; Allocating {currentTier.vcpu} vCPUs AMD EPYC [
                  <span className="text-emerald-400 font-bold">OK</span>]
                </div>
                <div className="text-slate-300">
                  &gt;&gt; Formatting {currentTier.nvmeGb}GB NVMe with ext4 [
                  <span className="text-emerald-400 font-bold">OK</span>]
                </div>
                <div className="text-slate-300">
                  &gt;&gt; {currentTier.bandwidthMbps} Mbps traffic allocated [
                  <span className="text-cyan-400 font-bold">UNLIMITED</span>]
                </div>
                <div className="text-slate-300">
                  &gt;&gt; Daily backup scheduler activated [
                  <span className="text-purple-400 font-bold">READY</span>]
                </div>
              </div>
            </div>

            {/* Bottom Heartbeat */}
            <div className="pt-4 border-t border-slate-800 text-[11px] text-emerald-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Heartbeat active: 100% Uptime across last 1,840 days</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
