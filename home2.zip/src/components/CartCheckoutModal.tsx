import React, { useState } from 'react';
import { BillingCycle, Currency } from '../types';
import { calculateOrderTotal, formatCurrency } from '../utils/pricing';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  Lock,
  QrCode,
  CreditCard,
  Zap,
  ArrowRight,
  Server,
} from 'lucide-react';

interface CartCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  planName: string;
  basePrice: number;
  initialCycle?: BillingCycle;
  currency: Currency;
}

export const CartCheckoutModal: React.FC<CartCheckoutModalProps> = ({
  isOpen,
  onClose,
  planName,
  basePrice,
  initialCycle = 'yearly',
  currency,
}) => {
  const [cycle, setCycle] = useState<BillingCycle>(initialCycle);
  const [domainName, setDomainName] = useState('');
  const [includeDomain, setIncludeDomain] = useState(false);
  const [includeDedicatedIp, setIncludeDedicatedIp] = useState(false);
  const [includePriorityBackup, setIncludePriorityBackup] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const order = calculateOrderTotal(basePrice, cycle, {
    dedicatedIp: includeDedicatedIp,
    priorityBackup: includePriorityBackup,
    domainRegistration: { isSelected: includeDomain, price: 75 },
  });

  const handleCompleteOrder = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-5 sm:p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#9810fa] flex items-center justify-center text-white">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">Configure Your Order</h3>
              <p className="text-xs text-slate-400">Automated Instant Provisioning · Tier-4 Mumbai</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-xs text-slate-700">
          {isSuccess ? (
            <div className="py-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="text-xl font-black text-slate-900">Account Provisioned Successfully!</h4>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                Your isolated cPanel instance on <strong>{planName}</strong> has been created with NVMe Gen4 storage.
                Your root credentials and activation invoice have been dispatched to your email.
              </p>
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-left max-w-sm mx-auto font-mono text-[11px] space-y-1">
                <div>Order ID: GIT-2026-{Math.floor(100000 + Math.random() * 900000)}</div>
                <div>Server Node: bom-tier4-cpanel</div>
                <div>Status: ACTIVE (100% HEALTH)</div>
              </div>
              <button
                onClick={onClose}
                className="px-6 py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs"
              >
                Close &amp; Go to Client Portal
              </button>
            </div>
          ) : (
            <>
              {/* Selected Plan Summary */}
              <div className="p-3.5 rounded-2xl bg-purple-50/70 border border-purple-200 flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-900 text-sm">{planName}</div>
                  <div className="text-[11px] text-[#820cd6]">LiteSpeed Web Server + Free Wildcard SSL</div>
                </div>
                <div className="text-right">
                  <div className="font-black text-slate-900 font-mono text-base">
                    {formatCurrency(basePrice, currency)}
                    <span className="text-[10px] font-normal text-slate-500">/mo</span>
                  </div>
                </div>
              </div>

              {/* Billing Cycle Toggle */}
              <div>
                <label className="font-bold text-slate-900 block mb-2">Select Billing Term:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setCycle('monthly')}
                    className={`p-3 rounded-xl border text-left font-semibold transition-all ${
                      cycle === 'monthly'
                        ? 'border-[#9810fa] bg-purple-50/50 text-blue-900 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-xs font-bold">1 Month Term</div>
                    <div className="text-[11px] text-slate-500">Regular billing</div>
                  </button>
                  <button
                    onClick={() => setCycle('yearly')}
                    className={`p-3 rounded-xl border text-left font-semibold transition-all relative ${
                      cycle === 'yearly'
                        ? 'border-[#9810fa] bg-purple-50/50 text-blue-900 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span className="absolute -top-2 right-2 bg-amber-400 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-full uppercase">
                      Save +10%
                    </span>
                    <div className="text-xs font-bold">12 Months (Yearly)</div>
                    <div className="text-[11px] text-emerald-700 font-semibold">Includes Free Domain</div>
                  </button>
                </div>
              </div>

              {/* Domain Input */}
              <div>
                <label className="font-bold text-slate-900 block mb-1.5">Choose Domain Name:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={domainName}
                    onChange={(e) => setDomainName(e.target.value)}
                    placeholder="myawesomebrand.com"
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-xl text-xs outline-hidden focus:border-[#9810fa]"
                  />
                  <label className="flex items-center gap-1.5 text-xs font-semibold cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={includeDomain}
                      onChange={(e) => setIncludeDomain(e.target.checked)}
                      className="rounded text-[#9810fa]"
                    />
                    <span>Register (₹75)</span>
                  </label>
                </div>
              </div>

              {/* Addons */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <label className="font-bold text-slate-900 block">Recommended Add-ons:</label>
                <div className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50">
                  <label className="flex items-center gap-2 cursor-pointer flex-1">
                    <input
                      type="checkbox"
                      checked={includeDedicatedIp}
                      onChange={(e) => setIncludeDedicatedIp(e.target.checked)}
                      className="rounded text-[#9810fa]"
                    />
                    <div>
                      <div className="font-semibold text-slate-900">Dedicated IPv4 Address</div>
                      <div className="text-[10px] text-slate-500">Improves email reputation &amp; SEO</div>
                    </div>
                  </label>
                  <span className="font-mono font-bold text-slate-700">+₹149/mo</span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50">
                  <label className="flex items-center gap-2 cursor-pointer flex-1">
                    <input
                      type="checkbox"
                      checked={includePriorityBackup}
                      onChange={(e) => setIncludePriorityBackup(e.target.checked)}
                      className="rounded text-[#9810fa]"
                    />
                    <div>
                      <div className="font-semibold text-slate-900">Continuous Hourly JetBackup</div>
                      <div className="text-[10px] text-slate-500">Real-time off-site replication</div>
                    </div>
                  </label>
                  <span className="font-mono font-bold text-slate-700">+₹49/mo</span>
                </div>
              </div>

              {/* Order Breakdown */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5 font-mono text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal ({cycle}):</span>
                  <span>{formatCurrency(order.subtotal, currency)}</span>
                </div>
                {order.savings > 0 && (
                  <div className="flex justify-between text-emerald-600 font-bold">
                    <span>Term Savings:</span>
                    <span>-{formatCurrency(order.savings, currency)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>GST (18%):</span>
                  <span>{formatCurrency(order.taxes, currency)}</span>
                </div>
                <div className="flex justify-between text-slate-900 font-black text-sm pt-2 border-t border-slate-200">
                  <span>Total Amount Due:</span>
                  <span className="text-[#820cd6]">{formatCurrency(order.total, currency)}</span>
                </div>
              </div>

              {/* Payment selector preview */}
              <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-800">
                <div className="flex items-center gap-2">
                  <QrCode className="w-4 h-4 text-emerald-700" />
                  <span className="font-bold">Instant UPI (GPay, PhonePe, Paytm) &amp; RuPay Supported</span>
                </div>
                <span className="font-mono font-bold">0% Surcharge</span>
              </div>
            </>
          )}
        </div>

        {/* Modal Footer */}
        {!isSuccess && (
          <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-4">
            <span className="text-[11px] text-slate-500 flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-emerald-600" /> 256-Bit SSL Encrypted Checkout
            </span>

            <button
              onClick={handleCompleteOrder}
              disabled={isProcessing}
              className="px-6 py-3 rounded-xl bg-[#9810fa] hover:bg-[#820cd6] text-white font-bold text-xs tracking-wide shadow-md transition-all active:scale-95 flex items-center gap-2 disabled:opacity-50"
            >
              {isProcessing ? 'Spinning Up Server...' : 'Complete & Launch Now'}
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
