import React, { useState, useEffect, useRef } from 'react';
import { TESTIMONIALS } from '../data/hostingData';
import { Testimonial } from '../types';
import {
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Star,
  CheckCircle2,
  MapPin,
  Layers,
  ArrowRight,
} from 'lucide-react';

export const IndustriesAndReviews: React.FC = () => {
  // Default to index 2 (Kavita Menon) so the center card matches the screenshot exactly
  const [activeIndex, setActiveIndex] = useState(2);
  const [isPaused, setIsPaused] = useState(false);
  const total = TESTIMONIALS.length;
  const touchStartXRef = useRef<number | null>(null);

  // Auto-advance every 5.5s unless paused by user interaction
  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % total);
    }, 5500);
    return () => clearInterval(timer);
  }, [isPaused, total]);

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % total);
  };

  const handlePrev = () => {
    setActiveIndex((prev) => (prev - 1 + total) % total);
  };

  // Touch swipe support for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchEndX - touchStartXRef.current;
    if (Math.abs(diff) > 40) {
      if (diff > 0) handlePrev();
      else handleNext();
    }
    touchStartXRef.current = null;
  };

  // 5 Top Brand Cards from Screenshot
  const brands = [
    {
      name: 'Google Cloud',
      type: 'Enterprise Cloud',
      logo: (
        <svg className="w-6 h-6 text-blue-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
    },
    {
      name: 'Shopify',
      type: 'Ecommerce Platform',
      logo: (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none">
          <path
            d="M17.8 4.2c-.1-.3-.4-.4-.6-.4h-2.1c-.2-1.3-.9-2.3-2.1-2.3-1.2 0-2 .9-2.2 2.3H8.7c-.3 0-.5.2-.6.5L4 19.5c-.1.3.1.6.4.7l12.8 2.3c.3.1.6-.1.7-.4l4.1-14.8c.1-.4 0-.7-.2-.9l-4-2.2z"
            fill="#95BF47"
          />
          <path
            d="M13 1.5c-.9 0-1.5.8-1.7 1.9h3.3c-.2-1.1-.8-1.9-1.6-1.9z"
            fill="#5E8E3E"
          />
          <path
            d="M13.2 8.7c-1.4 0-2.1.8-2.1 1.7 0 1.5 2.5 1.5 2.5 2.6 0 .5-.4.8-1 .8-.8 0-1.4-.4-1.6-.8l-.8.9c.4.7 1.3 1.1 2.3 1.1 1.5 0 2.3-.9 2.3-1.8 0-1.6-2.5-1.7-2.5-2.6 0-.4.3-.7.9-.7.7 0 1.2.3 1.4.7l.8-.9c-.4-.6-1.1-1-2.2-1z"
            fill="#FFFFFF"
          />
        </svg>
      ),
    },
    {
      name: 'Zomato',
      type: 'Food & Quick Commerce',
      logo: (
        <div className="w-6 h-6 rounded-full bg-[#e23744] flex items-center justify-center text-white font-black italic text-xs shadow-xs">
          z
        </div>
      ),
    },
    {
      name: 'Zoho',
      type: 'Cloud Business SaaS',
      logo: (
        <div className="grid grid-cols-2 gap-0.5 w-5 h-5">
          <div className="bg-[#e42528] rounded-xs" />
          <div className="bg-[#226bb4] rounded-xs" />
          <div className="bg-[#4aa942] rounded-xs" />
          <div className="bg-[#fdb813] rounded-xs" />
        </div>
      ),
    },
    {
      name: 'WordPress',
      type: 'CMS & Web Development',
      logo: (
        <div className="w-6 h-6 rounded-full bg-[#21759b] flex items-center justify-center text-white font-serif font-black text-xs shadow-xs">
          W
        </div>
      ),
    },
  ];

  return (
    <section
      className="py-16 sm:py-24 bg-white border-b border-purple-100/70 relative overflow-hidden select-none"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Background Grid Pattern (Blueprint square lines as in screenshot) */}
      <div className="absolute inset-0 bg-grid-pattern opacity-40 pointer-events-none" />

      {/* Ambient soft purple glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[450px] bg-purple-200/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* ============================================================== */}
        {/* SECTION 1: Industries We Serve                                 */}
        {/* ============================================================== */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            {/* Pill Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200/80 text-blue-600 text-xs font-semibold mb-3">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Industry Leaders &amp; Trusted Brands</span>
            </div>

            {/* Title & Subtitle */}
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Industries We Serve
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-2xl leading-relaxed">
              Powering high-growth digital infrastructure for 10,000+ businesses across e-commerce, fintech, cloud SaaS, and healthcare.
            </p>
          </div>

          {/* Step Navigation Controls (Right Aligned matching screenshot) */}
          <div className="flex items-center gap-3 self-start md:self-auto">
            <span className="text-xs text-slate-400 font-medium">Step Navigation</span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={handlePrev}
                className="w-8 h-8 rounded-lg bg-white border border-slate-200 hover:border-[#9810fa] hover:text-[#9810fa] text-slate-600 flex items-center justify-center transition-all shadow-2xs active:scale-95 cursor-pointer"
                aria-label="Previous card"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleNext}
                className="w-8 h-8 rounded-lg bg-white border border-slate-200 hover:border-[#9810fa] hover:text-[#9810fa] text-slate-600 flex items-center justify-center transition-all shadow-2xs active:scale-95 cursor-pointer"
                aria-label="Next card"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* 5 Horizontal Brand Cards in a Row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5 sm:gap-4 mb-20">
          {brands.map((b, idx) => (
            <div
              key={idx}
              className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs hover:shadow-md hover:border-[#9810fa]/50 transition-all flex items-center gap-3.5 group"
            >
              <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                {b.logo}
              </div>
              <div className="overflow-hidden">
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1">
                  <span className="truncate">{b.name}</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 fill-blue-50 shrink-0" />
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">{b.type}</div>
              </div>
            </div>
          ))}
        </div>

        {/* ============================================================== */}
        {/* SECTION 2: What Our Customers Say (3D Coverflow Perspective)  */}
        {/* ============================================================== */}
        <div className="text-center mb-12">
          <h2 className="text-4xl sm:text-5xl font-black text-slate-950 tracking-tight">
            What Our{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#9810fa] via-purple-600 to-[#7c3aed]">
              Customers
            </span>{' '}
            Say
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-3 max-w-2xl mx-auto leading-relaxed">
            Real feedback and ratings from developers, startups, and businesses scaling on Gitysoft cloud infrastructure.
          </p>
        </div>

        {/* 3D Coverflow Container */}
        <div
          className="relative min-h-[460px] flex items-center justify-center overflow-visible px-2 sm:px-0"
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          <div className="relative w-full max-w-[460px] h-[390px] flex items-center justify-center">
            {TESTIMONIALS.map((item: Testimonial, idx: number) => {
              // Calculate circular offset distance (-2, -1, 0, 1, 2)
              let offset = idx - activeIndex;
              if (offset > total / 2) offset -= total;
              if (offset < -total / 2) offset += total;

              // Hide cards that are far away from view
              const isVisible = Math.abs(offset) <= 2;
              if (!isVisible) return null;

              const isCenter = offset === 0;

              // Compute perspective positioning
              // Center: x = 0, scale = 1, zIndex = 30, opacity = 1
              // Left (-1): x = -230px, scale = 0.9, zIndex = 20, opacity = 0.65
              // Far Left (-2): x = -440px, scale = 0.8, zIndex = 10, opacity = 0.35
              // Right (+1): x = 230px, scale = 0.9, zIndex = 20, opacity = 0.65
              // Far Right (+2): x = 440px, scale = 0.8, zIndex = 10, opacity = 0.35
              const translateX =
                offset === 0
                  ? 0
                  : offset === -1
                  ? -230
                  : offset === 1
                  ? 230
                  : offset === -2
                  ? -440
                  : 440;

              const scale = isCenter ? 1 : Math.abs(offset) === 1 ? 0.9 : 0.8;
              const opacity = isCenter ? 1 : Math.abs(offset) === 1 ? 0.65 : 0.35;
              const zIndex = isCenter ? 30 : Math.abs(offset) === 1 ? 20 : 10;
              const blur = isCenter ? 'none' : Math.abs(offset) === 1 ? 'blur(0.4px)' : 'blur(1px)';

              return (
                <div
                  key={item.id}
                  onClick={() => setActiveIndex(idx)}
                  style={{
                    transform: `translate3d(${translateX}px, 0, 0) scale(${scale})`,
                    zIndex,
                    opacity,
                    filter: blur,
                  }}
                  className={`absolute top-0 w-full max-w-[440px] sm:max-w-[460px] bg-white rounded-3xl p-6 sm:p-7 transition-all duration-500 ease-out flex flex-col justify-between ${
                    isCenter
                      ? 'border-2 border-[#9810fa] shadow-2xl shadow-purple-500/20 ring-4 ring-[#9810fa]/10 cursor-default'
                      : 'border border-slate-200/90 shadow-md hover:opacity-90 cursor-pointer select-none'
                  }`}
                >
                  {/* Top Row: Avatar + Meta + Platform & Stars */}
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-3">
                      {/* Left: Avatar with small purple badge */}
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <img
                            src={item.avatar}
                            alt={item.name}
                            className="w-12 h-12 rounded-full object-cover border-2 border-purple-100 shadow-xs"
                          />
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-white flex items-center justify-center shadow-xs">
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#9810fa] fill-purple-100" />
                          </div>
                        </div>

                        <div>
                          <h3 className="font-extrabold text-slate-900 text-sm tracking-tight">
                            {item.name}
                          </h3>
                          <div className="text-[11px] text-slate-500 font-medium">
                            {item.role}
                          </div>
                          <div className="text-[11px] font-bold text-[#9810fa]">
                            {item.company}
                          </div>
                        </div>
                      </div>

                      {/* Right: Platform Badge, Stars & Verified Time */}
                      <div className="flex flex-col items-end">
                        {/* Platform Badge */}
                        {item.source === 'Google' && (
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-50 border border-slate-200 text-[11px] font-bold text-slate-700 shadow-2xs">
                            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                              <path
                                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                                fill="#4285F4"
                              />
                              <path
                                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                                fill="#34A853"
                              />
                              <path
                                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                                fill="#FBBC05"
                              />
                              <path
                                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                                fill="#EA4335"
                              />
                            </svg>
                            <span>Google</span>
                          </div>
                        )}

                        {item.source === 'Clutch' && (
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-50 border border-rose-200 text-[11px] font-bold text-[#ec2027] shadow-2xs">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#ec2027]" />
                            <span>Clutch</span>
                          </div>
                        )}

                        {item.source === 'GoodFirms' && (
                          <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-100 text-[11px] font-bold text-slate-700">
                            <span className="font-mono text-[9px] bg-slate-800 text-white px-1 rounded-xs">
                              GF
                            </span>
                            <span>GoodFirms</span>
                          </div>
                        )}

                        {item.source === 'Trustpilot' && (
                          <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] font-bold text-emerald-700">
                            <span className="text-emerald-500 font-bold">★</span>
                            <span>Trustpilot</span>
                          </div>
                        )}

                        {/* 5 Yellow Stars */}
                        <div className="flex items-center gap-0.5 mt-1">
                          {[...Array(item.rating)].map((_, i) => (
                            <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          ))}
                        </div>

                        {/* Relative Time */}
                        <div className="text-[10px] text-slate-400 font-medium text-right mt-0.5">
                          {item.verifiedTime}
                        </div>
                      </div>
                    </div>

                    {/* Subtle Quote Mark */}
                    <span className="text-2xl text-purple-300 font-serif block -mb-2 select-none">
                      ❝
                    </span>

                    {/* Quote Title */}
                    <h4 className="font-extrabold text-sm text-slate-900 mt-1 mb-1.5 leading-snug line-clamp-1">
                      &ldquo;{item.quoteTitle}&rdquo;
                    </h4>

                    {/* Quote Text */}
                    <p className="text-xs text-slate-600 leading-relaxed line-clamp-4">
                      {item.quote}
                    </p>
                  </div>

                  {/* Card Footer: Category Badge + Location + Read Story */}
                  <div className="flex items-center justify-between gap-2 pt-3 mt-3 border-t border-purple-100/80 text-[11px]">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-50 text-[#9810fa] font-bold border border-purple-100/70 truncate max-w-[170px]">
                      <Layers className="w-3 h-3 text-[#9810fa] shrink-0" />
                      <span className="truncate">{item.categoryTag}</span>
                    </span>

                    <span className="text-slate-400 flex items-center gap-1 font-medium shrink-0">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>{item.location}</span>
                    </span>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        // Smoothly brings to focus or shows feedback
                        setActiveIndex(idx);
                      }}
                      className="font-extrabold text-[#9810fa] hover:text-[#7d0bd2] flex items-center gap-0.5 cursor-pointer shrink-0"
                    >
                      <span>Read Story</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Carousel Indicators / Step Dots */}
        <div className="flex items-center justify-center gap-2 mt-8">
          {TESTIMONIALS.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setActiveIndex(idx)}
              className={`transition-all rounded-full cursor-pointer ${
                activeIndex === idx
                  ? 'w-7 h-2 bg-[#9810fa]'
                  : 'w-2 h-2 bg-purple-200 hover:bg-purple-300'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
