import React, { useState, useEffect } from 'react';
import { Currency } from '../types';
import {
  Globe,
  Server,
  Cpu,
  Mail,
  Layout,
  TrendingUp,
  MessageSquare,
  Smartphone,
  Palette,
  Code2,
  Lock,
  ArrowRight,
  Sparkles,
  Zap,
  CheckCircle2,
  Headphones,
  Search,
  Check,
  Shield,
  Activity,
  Star,
} from 'lucide-react';

interface HeroSectionProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number) => void;
  onOpenDomainSearch: () => void;
  onSelectService: (serviceName: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  currency = 'INR',
  onOpenCheckout,
  onOpenDomainSearch,
  onSelectService,
}) => {
  // Rotating headline phrases for the left title
  const phrases = [
    'Everything You Need to Create a Website',
    'Best Software Company & Cloud Platform',
    'High-Performance NVMe Cloud Hosting',
    'AI Website Builder & Enterprise Cloud',
    'Custom ERP, CRM & Mobile Engineering',
  ];
  const [currentPhraseIdx, setCurrentPhraseIdx] = useState(0);

  // Automatic multi-color cycle palette for the title
  const colorAccents = [
    'from-[#9810fa] via-[#ec4899] to-[#06b6d4]',
    'from-[#06b6d4] via-[#10b981] to-[#f59e0b]',
    'from-[#f59e0b] via-[#ef4444] to-[#9810fa]',
    'from-[#ec4899] via-[#8b5cf6] to-[#06b6d4]',
    'from-[#9810fa] via-[#3b82f6] to-[#10b981]',
  ];
  const [accentIdx, setAccentIdx] = useState(0);

  // Interactive right-side demo tab
  const [activeStack, setActiveStack] = useState<'wordpress' | 'ai-builder' | 'nodejs'>('wordpress');
  const [domainInput, setDomainInput] = useState('mybrand');

  // Simulated live countdown timer for the special deal
  const [countdown, setCountdown] = useState({ hours: 2, minutes: 48, seconds: 15 });

  useEffect(() => {
    const phraseTimer = setInterval(() => {
      setCurrentPhraseIdx((prev) => (prev + 1) % phrases.length);
      setAccentIdx((prev) => (prev + 1) % colorAccents.length);
    }, 2800);

    const clockTimer = setInterval(() => {
      setCountdown((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 2, minutes: 48, seconds: 15 };
      });
    }, 1000);

    return () => {
      clearInterval(phraseTimer);
      clearInterval(clockTimer);
    };
  }, [phrases.length, colorAccents.length]);

  const [hoveredServiceIdx, setHoveredServiceIdx] = useState<number | null>(1);

  // Dynamic animated laptop slides
  const [activeLaptopSlide, setActiveLaptopSlide] = useState(0);
  const [isSlidePaused, setIsSlidePaused] = useState(false);

  useEffect(() => {
    if (isSlidePaused) return;
    const slideTimer = setInterval(() => {
      setActiveLaptopSlide((prev) => (prev + 1) % 3);
    }, 3800);
    return () => clearInterval(slideTimer);
  }, [isSlidePaused]);

  const quickServices = [
    {
      name: 'Domain Registration',
      shortName: 'Domains',
      price: 'Starting ₹75/yr',
      icon: Globe,
      anchor: '#domains',
      badge: '500+ Extensions',
      desc: 'Instant .com, .in & .org domain setup with free DNS & WHOIS privacy protection.',
    },
    {
      name: 'Web Hosting',
      shortName: 'Web Hosting',
      price: 'Starting ₹99.99/mo',
      icon: Server,
      anchor: '#hosting-plans',
      isPopular: true,
      badge: '81% OFF • Most Popular',
      desc: 'Gen4 NVMe LiteSpeed servers, 1-click WordPress, free SSL & automated daily backups.',
    },
    {
      name: 'VPS & Dedicated Server',
      shortName: 'VPS / Dedicated',
      price: 'Starting ₹449/mo',
      icon: Cpu,
      isHot: true,
      anchor: '#cloud-vps',
      badge: 'HOT • Full Root SSH',
      desc: 'Dedicated vCPU & RAM, 10Gbps Tier-4 low-latency network with enterprise DDoS protection.',
    },
    {
      name: 'Business Email',
      shortName: 'Titan Email',
      price: 'Free with Hosting',
      icon: Mail,
      anchor: '#architecture',
      badge: '50GB Mailbox',
      desc: 'Professional inbox matching your domain with advanced AI spam defense & calendar sync.',
    },
    {
      name: 'Website Designing',
      shortName: 'Web Design',
      price: 'Starting ₹4,999',
      icon: Layout,
      anchor: '#digital-services',
      badge: 'Turnkey Design',
      desc: 'Modern, high-converting mobile-responsive websites built for growth & speed.',
    },
    {
      name: 'Digital Marketing',
      shortName: 'Marketing',
      price: 'Starting ₹3,999/mo',
      icon: TrendingUp,
      anchor: '#digital-services',
      badge: 'ROI Campaigns',
      desc: 'Google Ads, local SEO, social media marketing and brand growth strategies.',
    },
    {
      name: 'Bulk SMS',
      shortName: 'Bulk SMS',
      price: 'Starting 14p/SMS',
      icon: MessageSquare,
      anchor: '#digital-services',
      badge: 'DLT Approved',
      desc: 'Fast OTP routing, transactional alerts, and high-volume promotional SMS delivery.',
    },
    {
      name: 'Bulk WhatsApp',
      shortName: 'WhatsApp API',
      price: 'Starting 79p/msg',
      icon: Smartphone,
      isHot: true,
      anchor: '#digital-services',
      badge: 'HOT • 99% Opens',
      desc: 'Official WhatsApp Business API integration with automated broadcast campaigns.',
    },
    {
      name: 'Canva Pro Tools',
      shortName: 'Canva Pro',
      price: 'Starting ₹199/yr',
      icon: Palette,
      anchor: '#digital-services',
      badge: 'Creatives',
      desc: 'Access 100M+ assets, premium brand kits, and commercial graphic design tools.',
    },
    {
      name: 'Software Development',
      shortName: 'Software Dev',
      price: 'Custom Quote',
      icon: Code2,
      anchor: '#why-choose',
      badge: 'Custom SaaS',
      desc: 'End-to-end custom CRM, ERP, and bespoke mobile application engineering.',
    },
    {
      name: 'SSL Certificates',
      shortName: 'Wildcard SSL',
      price: 'Free Lifetime',
      icon: Lock,
      anchor: '#architecture',
      badge: 'Free Lifetime',
      desc: 'Instant wildcard 256-bit encryption with auto-renewal and green security padlock.',
    },
  ];

  return (
    <>
      <section className="relative bg-[#faf8fd] text-slate-900 overflow-hidden pt-12 sm:pt-16 pb-12 border-b border-purple-100/90">
        {/* Subtle Ambient Light Glows */}
        <div className="absolute inset-0 bg-grid-pattern opacity-40 pointer-events-none" />
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-[#9810fa]/8 rounded-full blur-[140px] pointer-events-none" />
        <div className="absolute top-10 left-10 w-[350px] h-[350px] bg-[#c084fc]/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
            {/* Left Column: Offer Headlines & Actions in Light Mode */}
            <div className="lg:col-span-5 space-y-6">
              <div>
                {/* Purple gradient subhead */}
                <h2 className="text-3xl sm:text-4xl lg:text-[46px] font-black tracking-tight leading-tight bg-gradient-to-r from-[#9810fa] via-[#a855f7] to-[#7c3aed] bg-clip-text text-transparent">
                  Up to 85% off
                </h2>

                {/* Main Headline in Bold Charcoal */}
                <h1 className="text-4xl sm:text-5xl lg:text-[54px] font-black text-slate-900 tracking-tight leading-[1.1] mt-1">
                  Web hosting this Black Friday
                </h1>
              </div>

              {/* Updated Checkmark Bullets */}
              <div className="space-y-3 pt-1">
                <div className="flex items-center gap-3 text-slate-700 text-sm sm:text-base font-semibold">
                  <div className="w-5 h-5 rounded-full bg-purple-50 text-[#9810fa] border border-purple-200 flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                  <span>99% Uptime Gurantee</span>
                </div>
                <div className="flex items-center gap-3 text-slate-700 text-sm sm:text-base font-semibold">
                  <div className="w-5 h-5 rounded-full bg-purple-50 text-[#9810fa] border border-purple-200 flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                  <span>Free Domain</span>
                </div>
              </div>

              {/* Price Tag Line with Exact Badge Design from Attachment */}
              <div className="flex items-center gap-3.5 pt-2">
                <span className="text-slate-600 text-sm sm:text-base font-medium">
                  From{' '}
                  <span className="line-through text-slate-400 font-mono font-semibold">
                    {currency === 'INR' ? '₹149.99' : '$12.99'}
                  </span>
                </span>

                {/* Compact Ticket Price Tag SVG with Pointed Left Arrow & Cutout Hole */}
                <div className="relative inline-flex items-center drop-shadow-md select-none transition-transform hover:scale-105">
                  <svg width="104" height="28" viewBox="0 0 104 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                    {/* Pointed ticket / price tag ribbon */}
                    <path
                      d="M12 0 C9.8 0 7.8 1.1 6.6 2.8 L1 11.5 C-0.3 13.5 -0.3 14.5 1 16.5 L6.6 25.2 C7.8 26.9 9.8 28 12 28 H98 C101.3 28 104 25.3 104 22 V6 C104 2.7 101.3 0 98 0 H12 Z"
                      fill="#ff385c"
                    />
                    {/* Small tag hole in the pointed chevron */}
                    <circle cx="8.5" cy="14" r="2.2" fill="#faf8fd" />
                    {/* Price Text */}
                    <text
                      x="57"
                      y="18.5"
                      fill="#ffffff"
                      fontSize="12"
                      fontWeight="800"
                      fontFamily="system-ui, -apple-system, sans-serif"
                      textAnchor="middle"
                    >
                      {currency === 'INR' ? '₹99.99/mo' : '$1.99/mo'}
                    </text>
                  </svg>
                </div>
              </div>

              {/* Claim Deal CTA Button with Exact #9810fa Color */}
              <div className="pt-2">
                <a
                  href="#hosting-plans"
                  onClick={() => onOpenCheckout('Web Hosting (Black Friday Deal)', currency === 'INR' ? 99.99 : 1.99)}
                  className="inline-flex items-center justify-center px-9 py-3.5 rounded-2xl bg-[#9810fa] hover:bg-[#840cd9] text-white font-black text-base shadow-lg shadow-[#9810fa]/30 hover:shadow-xl hover:shadow-[#9810fa]/40 transition-all duration-200 active:scale-95 cursor-pointer"
                >
                  Claim deal
                </a>
              </div>

              {/* Assistance Row without 30-day money-back guarantee */}
              <div className="flex items-center gap-2 pt-1 text-xs text-[#9810fa] font-bold">
                <Headphones className="w-4 h-4 text-[#9810fa]" />
                <span>24x7hrs Technical Assistance</span>
              </div>
            </div>

            {/* Right Column: 100% Transparent Background with Animated Dynamic Laptop Slides */}
            <div className="lg:col-span-7 relative flex items-center justify-center py-4">
              {/* Photorealistic Dark Laptop Frame on 100% Transparent Background */}
              <div className="relative z-10 mx-auto w-full max-w-[580px] drop-shadow-2xl">
                {/* Laptop Lid Bezel (Dark Graphite / Charcoal) */}
                <div className="bg-[#1e232e] rounded-t-2xl p-2 sm:p-2.5 pb-0 shadow-2xl border border-slate-700/80">
                  {/* Laptop Camera Notch */}
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-800 mx-auto mb-1.5 flex items-center justify-center border border-slate-700">
                    <div className="w-1 h-1 rounded-full bg-slate-900" />
                  </div>

                  {/* Screen Content Wrapper */}
                  <div className="bg-white rounded-t-xl overflow-hidden border border-slate-200 text-slate-800 font-sans shadow-inner">
                    {/* Browser Address Bar Header with Interactive Slide Indicators */}
                    <div className="bg-slate-100/95 px-3 py-1.5 border-b border-slate-200 flex items-center justify-between text-[11px]">
                      {/* Window Controls */}
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#ef4444] inline-block" />
                        <span className="w-2.5 h-2.5 rounded-full bg-[#f59e0b] inline-block" />
                        <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] inline-block" />
                      </div>

                      {/* URL Box Dynamically Changing with Active Slide */}
                      <div className="bg-white px-3 py-0.5 rounded-md border border-slate-200 text-slate-600 text-[10px] font-mono flex items-center gap-1.5 shadow-2xs max-w-[240px] truncate">
                        <Lock className="w-3 h-3 text-amber-500" />
                        <span>
                          {activeLaptopSlide === 0 && 'https://tools.gitysoft.com/gmb-scraper'}
                          {activeLaptopSlide === 1 && 'https://cloud.gitysoft.com/mumbai-tier4-node'}
                          {activeLaptopSlide === 2 && 'https://builder.gitysoft.com/instant-deploy'}
                        </span>
                      </div>

                      {/* Slide Indicator Selector Buttons */}
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setActiveLaptopSlide(0)}
                          className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded transition-all cursor-pointer ${
                            activeLaptopSlide === 0
                              ? 'bg-blue-600 text-white shadow-2xs'
                              : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                          }`}
                        >
                          GMB
                        </button>
                        <button
                          onClick={() => setActiveLaptopSlide(1)}
                          className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded transition-all cursor-pointer ${
                            activeLaptopSlide === 1
                              ? 'bg-[#9810fa] text-white shadow-2xs'
                              : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                          }`}
                        >
                          NVMe
                        </button>
                        <button
                          onClick={() => setActiveLaptopSlide(2)}
                          className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded transition-all cursor-pointer ${
                            activeLaptopSlide === 2
                              ? 'bg-emerald-600 text-white shadow-2xs'
                              : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                          }`}
                        >
                          AI Store
                        </button>
                      </div>
                    </div>

                    {/* DYNAMIC ANIMATED SLIDE 0: GMB Local Business Data Extractor */}
                    {activeLaptopSlide === 0 && (
                      <div className="animate-in fade-in zoom-in-95 duration-300">
                        {/* App Header Bar */}
                        <div className="p-3 sm:p-4 bg-white border-b border-slate-100 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-md bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-200">
                              <Server className="w-3.5 h-3.5" />
                            </div>
                            <span className="text-xs sm:text-sm font-bold text-slate-900">
                              GMB Local Business Data Extractor v4.2
                            </span>
                          </div>

                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                            1,480 Verified Records
                          </span>
                        </div>

                        {/* Filter / Input Controls Row */}
                        <div className="px-3 sm:px-4 py-2.5 bg-slate-50/70 border-b border-slate-200/80 flex flex-wrap items-center justify-between gap-3 text-left">
                          <div className="flex items-center gap-6">
                            <div>
                              <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">
                                Business Category
                              </div>
                              <div className="text-[11px] font-bold text-slate-800">Hotels &amp; Hospitality</div>
                            </div>

                            <div>
                              <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">
                                Target Region
                              </div>
                              <div className="text-[11px] font-bold text-slate-800">Mumbai &amp; Pune</div>
                            </div>
                          </div>

                          <button
                            onClick={onOpenDomainSearch}
                            className="px-3 py-1.5 rounded-lg bg-[#059669] hover:bg-[#047857] text-white font-bold text-[11px] flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                          >
                            <span className="text-[9px]">▶</span> Extract Leads
                          </button>
                        </div>

                        {/* Data Results Table */}
                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-[11px]">
                            <thead>
                              <tr className="bg-slate-50 border-b border-slate-200 text-[10px] text-slate-500 font-semibold">
                                <th className="py-2 px-3 sm:px-4">Business Name</th>
                                <th className="py-2 px-2 sm:px-3">Phone Number</th>
                                <th className="py-2 px-2 sm:px-3">Rating</th>
                                <th className="py-2 px-3 sm:px-4 text-right">Status</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 text-slate-700">
                              <tr className="hover:bg-slate-50/60 transition-colors">
                                <td className="py-2 px-3 sm:px-4 font-semibold text-slate-900">The Taj Mahal Palace</td>
                                <td className="py-2 px-2 sm:px-3 text-blue-600 font-mono">+91 22 6665-XXXX</td>
                                <td className="py-2 px-2 sm:px-3 text-amber-600 font-semibold">★ 4.9 (12.4k)</td>
                                <td className="py-2 px-3 sm:px-4 text-right text-emerald-600 font-bold text-[10px]">
                                  Verified
                                </td>
                              </tr>
                              <tr className="hover:bg-slate-50/60 transition-colors">
                                <td className="py-2 px-3 sm:px-4 font-semibold text-slate-900">Grand Hyatt Hotel</td>
                                <td className="py-2 px-2 sm:px-3 text-blue-600 font-mono">+91 22 6676-XXXX</td>
                                <td className="py-2 px-2 sm:px-3 text-amber-600 font-semibold">★ 4.8 (8.9k)</td>
                                <td className="py-2 px-3 sm:px-4 text-right text-emerald-600 font-bold text-[10px]">
                                  Verified
                                </td>
                              </tr>
                              <tr className="hover:bg-slate-50/60 transition-colors">
                                <td className="py-2 px-3 sm:px-4 font-semibold text-slate-900">The Westin Koregaon</td>
                                <td className="py-2 px-2 sm:px-3 text-blue-600 font-mono">+91 20 6721-XXXX</td>
                                <td className="py-2 px-2 sm:px-3 text-amber-600 font-semibold">★ 4.9 (6.7k)</td>
                                <td className="py-2 px-3 sm:px-4 text-right text-emerald-600 font-bold text-[10px]">
                                  Verified
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>

                        {/* App Internal Footer */}
                        <div className="px-3 sm:px-4 py-2 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-500">
                          <span>Processed 1,480 of 1,480 Entities</span>
                          <button
                            onClick={onOpenDomainSearch}
                            className="text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            📄 Export to Excel (.xlsx)
                          </button>
                        </div>

                        {/* Bottom Status Ribbon */}
                        <div className="px-3 sm:px-4 py-1.5 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-[10px]">
                          <span className="font-semibold text-slate-700">Google My Business Lead Scraper Tool</span>
                          <span className="text-emerald-700 font-bold flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Auto Active
                          </span>
                        </div>
                      </div>
                    )}

                    {/* DYNAMIC ANIMATED SLIDE 1: Gen4 NVMe Server Telemetry */}
                    {activeLaptopSlide === 1 && (
                      <div className="animate-in fade-in zoom-in-95 duration-300">
                        {/* Header */}
                        <div className="p-3 sm:p-4 bg-white border-b border-slate-100 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-md bg-purple-50 text-[#9810fa] flex items-center justify-center border border-purple-200">
                              <Activity className="w-3.5 h-3.5" />
                            </div>
                            <span className="text-xs sm:text-sm font-bold text-slate-900">
                              NVMe Cluster Telemetry · Mumbai MB1 Tier-4
                            </span>
                          </div>
                          <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200">
                            99.99% Guaranteed SLA
                          </span>
                        </div>

                        {/* 4 Performance Metric Cards */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3.5 bg-slate-50/70 border-b border-slate-200/80">
                          <div className="bg-white p-2.5 rounded-xl border border-purple-100 text-center shadow-xs">
                            <div className="text-base font-black font-mono text-[#9810fa]">7,500 MB/s</div>
                            <div className="text-[9px] text-slate-500 font-semibold uppercase">NVMe Read Speed</div>
                          </div>
                          <div className="bg-white p-2.5 rounded-xl border border-purple-100 text-center shadow-xs">
                            <div className="text-base font-black font-mono text-emerald-600">0.24s</div>
                            <div className="text-[9px] text-slate-500 font-semibold uppercase">TTFB Edge Latency</div>
                          </div>
                          <div className="bg-white p-2.5 rounded-xl border border-purple-100 text-center shadow-xs">
                            <div className="text-base font-black font-mono text-slate-900">HTTP/3</div>
                            <div className="text-[9px] text-slate-500 font-semibold uppercase">LiteSpeed QUIC</div>
                          </div>
                          <div className="bg-white p-2.5 rounded-xl border border-purple-100 text-center shadow-xs">
                            <div className="text-base font-black font-mono text-blue-600">99.4%</div>
                            <div className="text-[9px] text-slate-500 font-semibold uppercase">Redis Cache Hit</div>
                          </div>
                        </div>

                        {/* Live Server Log Lines */}
                        <div className="p-3 bg-slate-950 font-mono text-[10px] text-slate-300 space-y-1.5 h-[105px] overflow-hidden">
                          <div className="flex items-center gap-2 text-emerald-400">
                            <span className="text-slate-500">[05:48:12.1]</span>
                            <span>✓ TLS 1.3 Handshake completed in 1.4ms (AES-256-GCM)</span>
                          </div>
                          <div className="flex items-center gap-2 text-blue-300">
                            <span className="text-slate-500">[05:48:12.4]</span>
                            <span>⚡ LiteSpeed LSCache hit for 12,480 concurrent users</span>
                          </div>
                          <div className="flex items-center gap-2 text-purple-300">
                            <span className="text-slate-500">[05:48:12.8]</span>
                            <span>🔒 Automated CageFS memory isolation: 0 packet loss</span>
                          </div>
                        </div>

                        {/* Status bar */}
                        <div className="px-3 sm:px-4 py-1.5 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-[10px]">
                          <span className="font-semibold text-slate-700">Cluster: MB1-Tier4-Direct-NIXI</span>
                          <span className="text-emerald-700 font-bold flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> 100% Core Health
                          </span>
                        </div>
                      </div>
                    )}

                    {/* DYNAMIC ANIMATED SLIDE 2: AI Website & Store Engine */}
                    {activeLaptopSlide === 2 && (
                      <div className="animate-in fade-in zoom-in-95 duration-300">
                        {/* Header */}
                        <div className="p-3 sm:p-4 bg-white border-b border-slate-100 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-md bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-200">
                              <Sparkles className="w-3.5 h-3.5" />
                            </div>
                            <span className="text-xs sm:text-sm font-bold text-slate-900">
                              Autonomous AI Website &amp; Store Suite
                            </span>
                          </div>
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                            Instant 1-Click Launch
                          </span>
                        </div>

                        {/* Interactive Store Generation Preview */}
                        <div className="p-4 bg-gradient-to-br from-purple-50/50 via-white to-blue-50/40 border-b border-slate-200 text-left space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-slate-800">
                              eCommerce Architecture Setup Ready
                            </span>
                            <span className="text-[10px] font-black text-emerald-600 bg-emerald-100 px-2 py-0.5 rounded-full">
                              100% COMPLETE
                            </span>
                          </div>

                          <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                            <div className="p-2 rounded-lg bg-white border border-purple-200 shadow-2xs font-semibold">
                              🛍️ WooCommerce Pre-configured
                            </div>
                            <div className="p-2 rounded-lg bg-white border border-purple-200 shadow-2xs font-semibold">
                              💳 UPI &amp; Razorpay Ready
                            </div>
                            <div className="p-2 rounded-lg bg-white border border-purple-200 shadow-2xs font-semibold">
                              🔒 Wildcard SSL Active
                            </div>
                          </div>

                          <div className="p-2 rounded-xl bg-purple-50/80 border border-purple-200 flex items-center justify-between text-[11px]">
                            <span className="text-slate-600 font-medium">Domain: mybrand.in (1 Year Free)</span>
                            <a
                              href="#hosting-plans"
                              className="px-3 py-1 bg-[#9810fa] text-white font-bold rounded-lg text-[10px] shadow-xs hover:bg-[#820cd6] cursor-pointer"
                            >
                              Launch Store →
                            </a>
                          </div>
                        </div>

                        {/* Status bar */}
                        <div className="px-3 sm:px-4 py-1.5 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-[10px]">
                          <span className="font-semibold text-slate-700">AI Engine: Gitysoft Autonomous Builder</span>
                          <span className="text-purple-700 font-bold flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#9810fa] animate-pulse" /> Live Dynamic Active
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Laptop Bottom Base Stand with Thumb Indent */}
                <div className="relative -mt-0.5 mx-auto w-[104%] -left-[2%]">
                  <div className="h-3 sm:h-3.5 bg-gradient-to-b from-[#2d3442] via-[#242b38] to-[#171b24] rounded-b-xl shadow-xl flex items-start justify-center">
                    <div className="w-16 h-1 bg-[#12161f] rounded-b-md" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Social Proof Strip in Light Mode: Trustpilot (5/5 Rating on) & WordPress.org */}
          <div className="mt-14 pt-8 border-t border-purple-200/80 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-xs sm:text-sm text-slate-700">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-900">Excellent</span>
              {/* 5 Green Trustpilot Star Blocks */}
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="w-4 h-4 bg-[#00b67a] flex items-center justify-center text-white text-[10px] rounded-xs font-bold">
                    ★
                  </div>
                ))}
              </div>
              <span className="underline font-semibold cursor-pointer text-slate-900">5/5 Rating on</span>
              <span className="font-bold text-slate-900 flex items-center gap-1">
                <span className="text-[#00b67a]">★</span> Trustpilot
              </span>
            </div>

            <div className="hidden sm:block text-slate-300 font-light">|</div>

            <div className="flex items-center gap-2 text-slate-900 font-bold">
              {/* WordPress W Circle Logo */}
              <div className="w-4 h-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px] font-black leading-none">
                W
              </div>
              <span>Recommended by WordPress.org</span>
            </div>
          </div>
        </div>
      </section>

    {/* Long Collapse View with Hover Maximize / Minimize Animation */}
    <section id="quick-services" className="py-8 sm:py-10 bg-[#faf8fd] border-b border-purple-100/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-3 px-1">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#9810fa] animate-ping" />
              <span className="text-xs font-black text-slate-800 uppercase tracking-wider">
                Explore Cloud Ecosystem &amp; Digital Services
              </span>
            </div>
            <span className="text-[11px] font-bold text-slate-400 hidden sm:inline-flex items-center gap-1">
              <span>Hover over any service to maximize</span>
              <ArrowRight className="w-3 h-3 text-[#9810fa]" />
            </span>
          </div>

          {/* Desktop & Tablet: Long Expanding Accordion Strip */}
          <div
            onMouseLeave={() => setHoveredServiceIdx(1)}
            className="hidden md:flex flex-row items-stretch gap-2.5 w-full h-[210px] py-2 px-1 select-none"
          >
            {quickServices.map((service, idx) => {
              const IconComp = service.icon;
              const isHovered = (hoveredServiceIdx ?? 1) === idx;

              return (
                <a
                  key={idx}
                  href={service.anchor}
                  onMouseEnter={() => setHoveredServiceIdx(idx)}
                  onClick={() => onSelectService(service.name)}
                  style={{
                    flex: isHovered ? '4.2 1 0%' : '1 1 0%',
                    minWidth: isHovered ? '280px' : '64px',
                  }}
                  className={`relative rounded-2xl transition-all duration-500 ease-[cubic-bezier(0.25,1,0.5,1)] cursor-pointer overflow-hidden flex flex-col justify-between ${
                    isHovered
                      ? 'bg-white border-2 border-[#9810fa] shadow-xl shadow-purple-500/15 ring-4 ring-[#9810fa]/10 p-4 -translate-y-1 z-20'
                      : 'bg-white/90 hover:bg-white border border-purple-100/90 shadow-2xs hover:shadow-md p-2.5 z-10'
                  }`}
                >
                  {/* Expanded View */}
                  {isHovered ? (
                    <div className="flex flex-col justify-between h-full animate-in fade-in duration-300">
                      {/* Top Header */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8710f5] to-[#9810fa] text-white flex items-center justify-center shadow-md shadow-purple-500/25 shrink-0">
                          <IconComp className="w-5 h-5" />
                        </div>
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-50 text-[#9810fa] border border-purple-200/90 truncate shadow-2xs">
                          {service.badge}
                        </span>
                      </div>

                      {/* Middle Details */}
                      <div className="my-1.5">
                        <div className="flex items-center gap-1.5 mb-1">
                          <h4 className="text-sm font-extrabold text-slate-900 truncate">
                            {service.name}
                          </h4>
                          {service.isHot && (
                            <span className="px-1.5 py-0.2 bg-red-600 text-white font-extrabold text-[9px] rounded-full uppercase">
                              HOT
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                          {service.desc}
                        </p>
                      </div>

                      {/* Bottom Price & Action */}
                      <div className="flex items-center justify-between pt-2 border-t border-purple-100">
                        <span className="text-xs font-black text-[#9810fa] font-mono">
                          {service.price}
                        </span>
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-slate-800 hover:text-[#9810fa] transition-colors">
                          <span>Explore</span>
                          <ArrowRight className="w-3.5 h-3.5 text-[#9810fa]" />
                        </span>
                      </div>
                    </div>
                  ) : (
                    /* Minimized / Collapsed View */
                    <div className="flex flex-col items-center justify-between h-full py-1 text-center group">
                      <div className="w-9 h-9 rounded-xl bg-purple-50 group-hover:bg-[#9810fa] text-[#9810fa] group-hover:text-white flex items-center justify-center transition-colors shrink-0 shadow-2xs">
                        <IconComp className="w-4 h-4" />
                      </div>

                      <div className="my-auto px-0.5">
                        <span className="text-[11px] font-bold text-slate-700 group-hover:text-[#9810fa] line-clamp-2 leading-tight transition-colors block">
                          {service.shortName}
                        </span>
                      </div>

                      <span className="text-[9px] font-bold text-slate-500 font-mono truncate max-w-full">
                        {service.price.split(' ')[1] || service.price}
                      </span>
                    </div>
                  )}
                </a>
              );
            })}
          </div>

          {/* Mobile: Horizontal Swipeable Snap Carousel */}
          <div className="md:hidden flex gap-3 overflow-x-auto pb-3 pt-1 px-1 snap-x snap-mandatory scrollbar-none">
            {quickServices.map((service, idx) => {
              const IconComp = service.icon;
              return (
                <a
                  key={idx}
                  href={service.anchor}
                  onClick={() => onSelectService(service.name)}
                  className="w-[72vw] sm:w-[48vw] shrink-0 snap-center bg-white p-4 rounded-2xl border border-purple-200/90 shadow-md flex flex-col justify-between active:scale-98 transition-all"
                >
                  <div className="flex items-center justify-between mb-2.5">
                    <div className="w-10 h-10 rounded-xl bg-purple-50 text-[#9810fa] flex items-center justify-center">
                      <IconComp className="w-5 h-5" />
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-50 text-[#9810fa] border border-purple-200">
                      {service.badge}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-900 mb-1">{service.name}</h4>
                    <p className="text-[11px] text-slate-500 line-clamp-2 mb-3">{service.desc}</p>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-purple-100">
                    <span className="text-xs font-black text-[#9810fa] font-mono">{service.price}</span>
                    <span className="text-xs font-bold text-[#9810fa] flex items-center gap-1">
                      <span>Explore</span> <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </a>
              );
            })}
          </div>
        </div>
      </section>
    </>
  );
};
