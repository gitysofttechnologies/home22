import React, { useState } from 'react';
import { CATEGORIZED_FAQS } from '../data/hostingData';
import {
  HelpCircle,
  ChevronDown,
  ChevronUp,
  MessageCircle,
  Mail,
  ArrowRight,
  Sparkles,
  Server,
  Globe,
  Bot,
  Shield,
  RefreshCw,
} from 'lucide-react';

interface FaqSectionProps {
  onOpenLiveChat: () => void;
  onOpenEmailSupport: () => void;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ onOpenLiveChat, onOpenEmailSupport }) => {
  const [activeTabId, setActiveTabId] = useState<string>('popular');
  const [openFaqIndex, setOpenFaqIndex] = useState<number>(0);

  const activeCategory = CATEGORIZED_FAQS.find((c) => c.id === activeTabId) || CATEGORIZED_FAQS[0];
  const displayedFaqs = activeCategory.faqs.map((f) => ({ ...f, categoryName: activeCategory.name }));

  const toggleFaq = (idx: number) => {
    setOpenFaqIndex(openFaqIndex === idx ? -1 : idx);
  };

  const getTabIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className="w-4 h-4" />;
      case 'Server':
        return <Server className="w-4 h-4" />;
      case 'Globe':
        return <Globe className="w-4 h-4" />;
      case 'Bot':
        return <Bot className="w-4 h-4" />;
      case 'Shield':
        return <Shield className="w-4 h-4" />;
      default:
        return <RefreshCw className="w-4 h-4" />;
    }
  };

  return (
    <section id="faq" className="py-20 bg-[#faf8fd] border-b border-purple-100/80 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 leading-tight">
            Frequently Asked <span className="text-[#9810fa]">Questions</span>
          </h2>
          <p className="mt-2.5 text-xs sm:text-sm text-slate-600">
            Browse commonly asked questions about our hosting, infrastructure, and technical support.
          </p>
        </div>

        {/* Multi-Tabs Navigation Bar (No 5/4 Numbering) */}
        <div className="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {CATEGORIZED_FAQS.map((category) => {
            const isActive = activeTabId === category.id;
            return (
              <button
                key={category.id}
                onClick={() => {
                  setActiveTabId(category.id);
                  setOpenFaqIndex(0);
                }}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#9810fa] text-white shadow-md shadow-[#9810fa]/25 scale-102'
                    : 'bg-white border border-purple-100 text-slate-600 hover:text-[#9810fa] hover:border-purple-300'
                }`}
              >
                <span className={isActive ? 'text-white' : 'text-[#9810fa]'}>
                  {getTabIcon(category.icon)}
                </span>
                <span>{category.name}</span>
              </button>
            );
          })}
        </div>

        {/* FAQ Accordion Layout (Full Width Centered) */}
        <div className="max-w-4xl mx-auto space-y-3.5">
          {displayedFaqs.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-3xl border border-purple-100">
              <HelpCircle className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <div className="text-sm font-bold text-slate-800">No questions found in this category.</div>
              <div className="text-xs text-slate-500 mt-1">Please select another category above.</div>
            </div>
          ) : (
            displayedFaqs.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                    isOpen
                      ? 'border-[#9810fa]/80 bg-white shadow-md ring-2 ring-[#9810fa]/10'
                      : 'border-purple-100 bg-white hover:border-purple-200'
                  }`}
                >
                  <button
                    onClick={() => toggleFaq(idx)}
                    className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`text-xs sm:text-sm font-black ${
                          isOpen ? 'text-[#9810fa]' : 'text-slate-900'
                        }`}
                      >
                        {faq.question}
                      </span>
                      {faq.badge && (
                        <span className="hidden sm:inline-block text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-[#9810fa]/10 text-[#9810fa] shrink-0">
                          {faq.badge}
                        </span>
                      )}
                    </div>
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                        isOpen ? 'bg-[#9810fa] text-white' : 'bg-purple-50 text-slate-600'
                      }`}
                    >
                      {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs text-slate-600 leading-relaxed border-t border-purple-50 animate-in fade-in duration-150">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </section>
  );
};
