import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';
import { Currency } from '../types';

interface FloatingActionsProps {
  onOpenLiveChat?: () => void;
  currency?: Currency;
  setCurrency?: (c: Currency) => void;
}

export const FloatingActions: React.FC<FloatingActionsProps> = () => {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!showScrollTop) return null;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 pointer-events-auto">
      {/* Back to top button */}
      <button
        onClick={scrollToTop}
        className="w-11 h-11 rounded-full bg-[#120524] hover:bg-[#200940] text-white flex flex-col items-center justify-center text-[8px] font-black uppercase tracking-tighter shadow-2xl transition-all active:scale-95 group border border-purple-800 animate-in fade-in slide-in-from-bottom-2 duration-200 cursor-pointer"
        aria-label="Back to top"
      >
        <ArrowUp className="w-3.5 h-3.5 group-hover:-translate-y-0.5 transition-transform text-[#c084fc]" />
        <span className="leading-none mt-0.5">TOP</span>
      </button>
    </div>
  );
};
