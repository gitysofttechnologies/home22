import React from 'react';
import { Currency } from '../types';
import { formatCurrency } from '../utils/pricing';
import { Check, X, ArrowRight } from 'lucide-react';

interface PriceComparisonProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number) => void;
}

export const PriceComparison: React.FC<PriceComparisonProps> = ({ currency, onOpenCheckout }) => {
  const comparisonRows = [
    {
      feature: 'Starting Price',
      gitysoft: formatCurrency(99.99, currency) + '/mo',
      godaddy: formatCurrency(199, currency) + '/mo',
      hostinger: formatCurrency(149, currency) + '/mo',
      bluehost: formatCurrency(299, currency) + '/mo',
      isText: true,
    },
    {
      feature: 'Free Domain',
      gitysoft: true,
      godaddy: false,
      hostinger: false,
      bluehost: false,
    },
    {
      feature: 'NVMe Storage',
      gitysoft: '10 GB NVMe',
      godaddy: '5 GB HDD',
      hostinger: '10 GB SSD',
      bluehost: '10 GB SSD',
      isText: true,
    },
    {
      feature: 'Free SSL Certificate',
      gitysoft: true,
      godaddy: true,
      hostinger: true,
      bluehost: true,
    },
    {
      feature: 'Daily Automated Backup',
      gitysoft: true,
      godaddy: false,
      hostinger: true,
      bluehost: true,
    },
    {
      feature: 'Business Email Included',
      gitysoft: true,
      godaddy: false,
      hostinger: true,
      bluehost: true,
    },
    {
      feature: '24x7hrs Technical Assistance',
      gitysoft: true,
      godaddy: true,
      hostinger: true,
      bluehost: true,
    },
    {
      feature: 'Renewal Price',
      gitysoft: 'Same Flat Rate',
      godaddy: 'Significantly Higher',
      hostinger: 'Significantly Higher',
      bluehost: 'Significantly Higher',
      isRenewal: true,
    },
  ];

  return (
    <section id="price-comparison" className="py-20 bg-slate-50/50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-10 text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900">
            Compare & Choose the Best Value
          </h2>
          <p className="mt-3 text-base text-slate-600">
            See how Gitysoft delivers industry-leading enterprise specs with transparent pricing, maximum performance, and 24x7hrs Technical Assistance.
          </p>
        </div>

        {/* Full Width Table Container */}
        <div className="w-full overflow-x-auto rounded-3xl border border-purple-100 shadow-xl bg-white">
          <table className="w-full text-left text-xs sm:text-sm border-collapse min-w-[640px]">
            <thead>
              <tr className="border-b border-purple-100 bg-slate-50/70">
                <th className="py-5 px-5 sm:px-7 font-bold text-slate-700 text-sm">Features & Resources</th>
                <th className="py-5 px-5 sm:px-7 font-extrabold text-[#9810fa] bg-purple-50/80 border-x border-purple-200 text-center min-w-[180px]">
                  <div className="text-base sm:text-lg font-black text-[#9810fa]">Gitysoft</div>
                  <span className="text-[10px] font-black uppercase tracking-wider bg-[#9810fa] text-white px-2.5 py-0.5 rounded-full shadow-xs inline-block mt-1">
                    Best Value
                  </span>
                </th>
                <th className="py-5 px-5 sm:px-7 font-bold text-slate-600 text-center">GoDaddy</th>
                <th className="py-5 px-5 sm:px-7 font-bold text-slate-600 text-center">Hostinger</th>
                <th className="py-5 px-5 sm:px-7 font-bold text-slate-600 text-center">Bluehost</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {comparisonRows.map((row, idx) => (
                <tr key={idx} className="hover:bg-purple-50/20 transition-colors">
                  <td className="py-4 px-5 sm:px-7 font-semibold text-slate-800">{row.feature}</td>

                  {/* Gitysoft Highlighted Column */}
                  <td className="py-4 px-5 sm:px-7 text-center font-bold bg-purple-50/40 border-x border-purple-200/70 text-slate-900">
                    {row.isText ? (
                      <span className="font-mono text-[#9810fa] font-bold">{row.gitysoft}</span>
                    ) : row.isRenewal ? (
                      <span className="text-[#9810fa] font-extrabold">{row.gitysoft}</span>
                    ) : row.gitysoft ? (
                      <div className="w-5 h-5 mx-auto rounded-full bg-[#9810fa] text-white flex items-center justify-center shadow-xs">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                    ) : (
                      <div className="w-5 h-5 mx-auto rounded-full bg-slate-200 text-slate-400 flex items-center justify-center">
                        <X className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </td>

                  {/* GoDaddy */}
                  <td className="py-4 px-5 sm:px-7 text-center text-slate-600">
                    {row.isText ? (
                      row.godaddy
                    ) : row.isRenewal ? (
                      <span className="text-red-500 font-medium">{row.godaddy}</span>
                    ) : row.godaddy ? (
                      <Check className="w-4 h-4 text-emerald-500 mx-auto" />
                    ) : (
                      <X className="w-4 h-4 text-slate-300 mx-auto" />
                    )}
                  </td>

                  {/* Hostinger */}
                  <td className="py-4 px-5 sm:px-7 text-center text-slate-600">
                    {row.isText ? (
                      row.hostinger
                    ) : row.isRenewal ? (
                      <span className="text-red-500 font-medium">{row.hostinger}</span>
                    ) : row.hostinger ? (
                      <Check className="w-4 h-4 text-emerald-500 mx-auto" />
                    ) : (
                      <X className="w-4 h-4 text-slate-300 mx-auto" />
                    )}
                  </td>

                  {/* Bluehost */}
                  <td className="py-4 px-5 sm:px-7 text-center text-slate-600">
                    {row.isText ? (
                      row.bluehost
                    ) : row.isRenewal ? (
                      <span className="text-red-500 font-medium">{row.bluehost}</span>
                    ) : row.bluehost ? (
                      <Check className="w-4 h-4 text-emerald-500 mx-auto" />
                    ) : (
                      <X className="w-4 h-4 text-slate-300 mx-auto" />
                    )}
                  </td>
                </tr>
              ))}

              {/* Bottom Row Action */}
              <tr className="bg-purple-50/30">
                <td className="py-5 px-5 sm:px-7 font-bold text-xs sm:text-sm text-slate-700">
                  Ultra-Fast NVMe LiteSpeed Cloud Hosting
                </td>
                <td className="py-5 px-5 sm:px-7 text-center bg-purple-50/60 border-x border-purple-200">
                  <button
                    onClick={() => onOpenCheckout('Premium Hosting', 99.99)}
                    className="px-5 py-2.5 rounded-xl bg-[#9810fa] hover:bg-[#830bd8] text-white font-bold text-xs shadow-md shadow-purple-500/25 transition-all active:scale-95 whitespace-nowrap inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    Get Started <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </td>
                <td className="py-5 px-5 sm:px-7 text-center text-slate-400 font-medium">—</td>
                <td className="py-5 px-5 sm:px-7 text-center text-slate-400 font-medium">—</td>
                <td className="py-5 px-5 sm:px-7 text-center text-slate-400 font-medium">—</td>
              </tr>
            </tbody>
          </table>

          {/* Footnote */}
          <div className="p-4 sm:px-7 text-xs text-slate-500 flex flex-wrap items-center justify-between border-t border-purple-100 bg-slate-50/60 gap-2">
            <span>* Pricing data regularly verified based on publicly listed standard renewal rates.</span>
            <span className="font-semibold text-[#9810fa]">Transparent pricing & renewal lock-in</span>
          </div>
        </div>
      </div>
    </section>
  );
};
