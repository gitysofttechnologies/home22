import React, { useState } from 'react';
import {
  Globe,
  ArrowRight,
  MapPin,
} from 'lucide-react';

interface GlobalInfrastructureProps {
  onOpenCheckout: (planName: string, price: number) => void;
}

export const GlobalInfrastructure: React.FC<GlobalInfrastructureProps> = ({ onOpenCheckout }) => {
  const [selectedRegion, setSelectedRegion] = useState('Europe');

  const regionLocations: Record<string, { city: string; country: string; ping: string; type: string }> = {
    Americas: { city: 'Ashburn, Virginia', country: 'United States', ping: '142.0 ms', type: 'Anycast DNS & Storage' },
    Europe: { city: 'Frankfurt', country: 'Germany', ping: '98.2 ms', type: 'Active Edge Node' },
    Asia: { city: 'Mumbai (MB1)', country: 'India', ping: '2.1 ms', type: 'Primary Tier-4 DC' },
    'Middle East': { city: 'Dubai', country: 'UAE', ping: '38.4 ms', type: 'Edge Routing Point' },
    Australia: { city: 'Sydney', country: 'Australia', ping: '168.0 ms', type: 'Edge Acceleration Node' },
  };

  const currentLocation = regionLocations[selectedRegion] || regionLocations['Europe'];

  return (
    <section id="global-datacenters" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section 1: Closer to You, Faster for Everyone */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 leading-tight">
              Closer to You, <br className="hidden sm:inline" />
              Faster for Everyone
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-600">
              Our strategically located data centers ensure low latency, high performance, and unmatched reliability.
            </p>
          </div>

          <button
            onClick={() => onOpenCheckout('Global Anycast Cloud Node', 1499)}
            className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs tracking-wide shadow-md transition-all shrink-0 flex items-center gap-2 self-start md:self-auto cursor-pointer"
          >
            View All Locations <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Region Tabs (Americas, Europe, Asia, Middle East, Australia) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8">
          {['Americas', 'Europe', 'Asia', 'Middle East', 'Australia'].map((reg) => (
            <button
              key={reg}
              onClick={() => setSelectedRegion(reg)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                selectedRegion === reg
                  ? 'bg-[#9810fa] text-white shadow-md'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {reg}
            </button>
          ))}
        </div>

        {/* Map & Global Edge Visual */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left: 50+ Global Locations with interactive points */}
          <div className="lg:col-span-8 bg-purple-50/50 rounded-3xl p-6 sm:p-8 border border-purple-100 relative overflow-hidden flex flex-col justify-between min-h-[340px]">
            {/* SVG Globe Network Background */}
            <div className="absolute inset-0 flex items-center justify-center opacity-30 pointer-events-none">
              <svg className="w-full h-full" viewBox="0 0 600 300" fill="none">
                <circle cx="150" cy="140" r="80" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4 4" />
                <circle cx="350" cy="120" r="120" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4 4" />
                <circle cx="500" cy="180" r="60" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4 4" />
                <path d="M 150 140 Q 250 80 350 120 T 500 180" stroke="#2563eb" strokeWidth="2" />
                {/* Node dots */}
                <circle cx="150" cy="140" r="6" fill="#2563eb" className="animate-ping" />
                <circle cx="150" cy="140" r="4" fill="#1d4ed8" />
                <circle cx="280" cy="100" r="4" fill="#3b82f6" />
                <circle cx="350" cy="120" r="6" fill="#10b981" />
                <circle cx="420" cy="140" r="4" fill="#3b82f6" />
                <circle cx="500" cy="180" r="5" fill="#3b82f6" />
              </svg>
            </div>

            {/* Floating Location Card */}
            <div className="bg-white/95 backdrop-blur-md rounded-2xl p-5 border border-slate-200 shadow-xl max-w-sm relative z-10">
              <div className="text-2xl font-black text-slate-900 font-mono">50+</div>
              <div className="text-xs font-bold text-[#9810fa] mb-1">Global Locations</div>
              <p className="text-[11px] text-slate-600 mb-3 leading-relaxed">
                Delivering a faster, more reliable internet experience — no matter where you are.
              </p>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-rose-500" />
                  <span className="font-bold text-slate-900">
                    {currentLocation.city}, {currentLocation.country}
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  {currentLocation.type}
                </span>
              </div>
            </div>

            {/* Bottom badges */}
            <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-slate-700 relative z-10 pt-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#9810fa]" /> 100% NVMe Edge
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" /> Tier IV Certified
              </span>
              <span className="flex items-center gap-1.5 font-mono text-[#9810fa] ml-auto">
                Ping: {currentLocation.ping}
              </span>
            </div>
          </div>

          {/* Right: Growing Together Across the Globe */}
          <div className="lg:col-span-4 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xl flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-purple-50 text-[#9810fa] flex items-center justify-center mb-6 border border-purple-100">
                <Globe className="w-6 h-6" />
              </div>

              <h3 className="text-2xl font-black text-slate-900 leading-snug mb-3">
                Growing Together Across the Globe
              </h3>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
                Join 1+ million developers, agencies, and businesses scaling with Gitysoft high-availability cloud
                infrastructure.
              </p>
            </div>

            <button
              onClick={() => onOpenCheckout('Global Enterprise Cloud Cluster', 4999)}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-[#9810fa] hover:from-purple-700 hover:to-[#8409dc] text-white font-bold text-xs tracking-wide shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            >
              Join Thousands Today <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
