export type BillingCycle = 'monthly' | 'yearly' | '24months' | '48months';
export type PlanTerm = '48' | '24' | '12' | '1';
export type Currency = 'INR' | 'USD';

export interface HostingPlan {
  id: string;
  name: string;
  badge?: string;
  badgeType?: 'popular' | 'discount' | 'neutral';
  discount?: string;
  monthlyPrice: number;
  originalPrice: number;
  description: string;
  renewalPriceText: string;
  perks: {
    text: string;
    badge?: string;
    isNegative?: boolean;
    info?: string;
  }[];
  specs: {
    websites: string;
    storage: string;
    emails: string;
    aiBuilder: boolean;
    ftp: string;
    bandwidth: string;
    vcpu: string;
    ram: string;
    ioLimit: string;
    sqlDatabases: string;
    addonDatabases?: boolean;
  };
}

export interface VpsTier {
  id: string;
  tierNumber: number;
  name: string;
  popularTag?: string;
  monthlyPrice: number;
  originalPrice: number;
  discountBadge: string;
  vcpu: number;
  ramGb: number;
  nvmeGb: number;
  bandwidthMbps: number;
  features: string[];
}

export interface DedicatedServer {
  id: string;
  model: string;
  category: string;
  node: string;
  coresThreads: string;
  cpuModel: string;
  ram: string;
  storage: string;
  network: string;
  monthlyPrice: number;
  deployTime: string;
  features: string[];
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  avatar: string;
  quoteTitle: string;
  quote: string;
  rating: number;
  source: 'Trustpilot' | 'Clutch' | 'Google' | 'GoodFirms';
  verifiedTime: string;
  categoryTag: string;
  location: string;
  projectScope?: string;
  clutchReviewId?: string;
}

export interface LeadRecord {
  id: string;
  businessName: string;
  category: string;
  phone: string;
  rating: number;
  reviewsCount: string;
  region: string;
  status: 'Verified' | 'Pending';
}

export interface CartItem {
  planId: string;
  planName: string;
  serviceCategory: string;
  billingCycle: BillingCycle;
  basePrice: number;
  domainName?: string;
  dedicatedIp?: boolean;
  sslCertificate?: boolean;
  totalPrice: number;
}
