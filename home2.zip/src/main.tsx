import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Ensure window.fetch has a setter to prevent Chrome extensions from throwing TypeError: Cannot set property fetch of #<Window> which has only a getter
try {
  let _currentFetch = window.fetch;
  Object.defineProperty(window, 'fetch', {
    get() {
      return _currentFetch;
    },
    set(fn) {
      _currentFetch = fn;
    },
    configurable: true,
    enumerable: true,
  });
} catch (_) {}

createRoot(document.getElementById('root')!).render(<App />);
