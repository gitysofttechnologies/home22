import { BillingCycle, Currency, LeadRecord } from '../types';

export const USD_RATE = 0.012; // 1 INR ~ 0.012 USD approx

/**
 * Calculates effective monthly price based on billing cycle (yearly gives extra 10% discount)
 */
export function calculateEffectiveMonthlyPrice(
  monthlyPrice: number,
  cycle: BillingCycle,
  yearlyDiscountPercent = 10
): number {
  if (cycle === '48months') {
    return Math.round(monthlyPrice * 0.45 * 100) / 100;
  }
  if (cycle === '24months') {
    return Math.round(monthlyPrice * 0.65 * 100) / 100;
  }
  if (cycle === 'yearly') {
    const discounted = monthlyPrice * (1 - yearlyDiscountPercent / 100);
    return Math.round(discounted * 100) / 100;
  }
  return monthlyPrice;
}

/**
 * Calculates the total order amount for checkout
 */
export function calculateOrderTotal(
  baseMonthlyPrice: number,
  cycle: BillingCycle,
  addons: {
    dedicatedIp?: boolean; // ₹149/mo
    domainRegistration?: { isSelected: boolean; price: number };
    priorityBackup?: boolean; // ₹49/mo
  }
): { subtotal: number; taxes: number; total: number; savings: number } {
  const months = cycle === '48months' ? 48 : cycle === '24months' ? 24 : cycle === 'yearly' ? 12 : 1;
  const effectiveMonthly = calculateEffectiveMonthlyPrice(baseMonthlyPrice, cycle);

  let monthlyAddons = 0;
  if (addons.dedicatedIp) monthlyAddons += 149;
  if (addons.priorityBackup) monthlyAddons += 49;

  const basePeriodCost = effectiveMonthly * months;
  const addonsCost = monthlyAddons * months;
  const domainCost = addons.domainRegistration?.isSelected ? addons.domainRegistration.price : 0;

  const subtotal = Math.round((basePeriodCost + addonsCost + domainCost) * 100) / 100;
  const taxes = Math.round(subtotal * 0.18 * 100) / 100; // 18% GST in India
  const total = Math.round((subtotal + taxes) * 100) / 100;

  // Calculate savings vs full monthly regular price without yearly discount
  const regularPeriodCost = baseMonthlyPrice * months;
  const savings = Math.max(0, Math.round((regularPeriodCost - basePeriodCost) * 100) / 100);

  return { subtotal, taxes, total, savings };
}

/**
 * Formats amount into INR or USD
 */
export function formatCurrency(amount: number, currency: Currency = 'INR'): string {
  if (currency === 'USD') {
    const usdVal = amount * USD_RATE;
    return `$${usdVal.toFixed(2)}`;
  }
  const hasDecimals = amount % 1 !== 0;
  return `₹${amount.toLocaleString('en-IN', {
    minimumFractionDigits: hasDecimals ? 2 : 0,
    maximumFractionDigits: 2,
  })}`;
}

/**
 * Calculates savings compared to competitor
 */
export function calculateCompetitorSavings(gitysoftPrice: number, competitorPrice: number): number {
  if (competitorPrice <= gitysoftPrice) return 0;
  return Math.round(((competitorPrice - gitysoftPrice) / competitorPrice) * 100);
}

/**
 * Filters lead records by category and region
 */
export function filterLeads(
  leads: LeadRecord[],
  categoryFilter?: string,
  regionFilter?: string
): LeadRecord[] {
  return leads.filter((lead) => {
    const matchesCategory =
      !categoryFilter ||
      categoryFilter === 'All' ||
      lead.category.toLowerCase().includes(categoryFilter.toLowerCase());
    const matchesRegion =
      !regionFilter ||
      regionFilter === 'All' ||
      lead.region.toLowerCase().includes(regionFilter.toLowerCase());
    return matchesCategory && matchesRegion;
  });
}
